package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"apirusdotistamobile/internal/model"
)

type BookingRepository struct {
	DB *sql.DB
}

type BookingTarget struct {
	PatientID   int64
	NoRM        string
	Email       string
	PoliID      int64
	Tanggal     time.Time
	Bayar       string
	JenisPasien string
	DoctorID    string
	QueueGroup  string
	IsJkn       bool
}

type BookingListFilter struct {
	Status    string
	Date      *time.Time
	Limit     int
	PatientID int64
}

type bookingContext struct {
	poliID      int64
	poliName    string
	poliBPJS    string
	doctorID    string
	queueGroup  string
	queueDate   time.Time
	serviceMode string
}

func NewBookingRepository(db *sql.DB) *BookingRepository {
	return &BookingRepository{DB: db}
}

func (r *BookingRepository) BookingOptions(ctx context.Context, poliID int64) (*model.BookingOptionsResponse, error) {
	if poliID <= 0 {
		return nil, errors.New("poli tidak valid")
	}

	var poli model.BookingPoliOption
	if err := r.DB.QueryRowContext(ctx, `
		SELECT
			p.id,
			COALESCE(p.nama, ''),
			COALESCE(p.kelompok, ''),
			COALESCE(p.politype, ''),
			COALESCE(p.bpjs, ''),
			COALESCE(p.kode_ruangan, ''),
			COALESCE(DATE_FORMAT(p.buka, '%H:%i'), ''),
			COALESCE(DATE_FORMAT(p.tutup, '%H:%i'), ''),
			COALESCE(p.praktik, ''),
			COALESCE(p.kelompok, ''),
			COALESCE(p.bpjs, '')
		FROM polis p
		WHERE p.id = ?
		LIMIT 1
	`, poliID).Scan(
		&poli.ID,
		&poli.Nama,
		&poli.Kelompok,
		&poli.Politype,
		&poli.BpjsCode,
		&poli.KodeRuangan,
		&poli.Buka,
		&poli.Tutup,
		&poli.Praktik,
		&poli.QueueGroup,
		&poli.QueueGroupHint,
	); err != nil {
		return nil, err
	}

	doctorIDs := splitDoctorIDs(poliID, r.DB)
	if len(doctorIDs) > 0 {
		placeholders := strings.TrimSuffix(strings.Repeat("?,", len(doctorIDs)), ",")
		args := make([]any, 0, len(doctorIDs))
		for _, id := range doctorIDs {
			args = append(args, id)
		}
		query := fmt.Sprintf(`
			SELECT id, COALESCE(nama, ''), COALESCE(kode_antrian, ''), COALESCE(kode_bpjs, ''), COALESCE(general_code, '')
			FROM pegawais
			WHERE id IN (%s)
			ORDER BY nama ASC
		`, placeholders)
		rows, err := r.DB.QueryContext(ctx, query, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var doctor model.BookingDoctorOption
				if err = rows.Scan(&doctor.ID, &doctor.Nama, &doctor.KodeAntrian, &doctor.KodeBpjs, &doctor.GeneralCode); err != nil {
					return nil, err
				}
				poli.Doctors = append(poli.Doctors, doctor)
			}
			if err = rows.Err(); err != nil {
				return nil, err
			}
		}
	}

	if poli.QueueGroup == "" {
		poli.QueueGroup = poli.Kelompok
	}
	if poli.QueueGroupHint == "" {
		poli.QueueGroupHint = poli.Politype
	}

	return &model.BookingOptionsResponse{Poli: poli}, nil
}

func splitDoctorIDs(poliID int64, db *sql.DB) []int64 {
	var raw sql.NullString
	if err := db.QueryRow(`SELECT COALESCE(dokter_id, '') FROM polis WHERE id = ? LIMIT 1`, poliID).Scan(&raw); err != nil || !raw.Valid {
		return nil
	}

	parts := strings.Split(raw.String, ",")
	ids := make([]int64, 0, len(parts))
	for _, part := range parts {
		id, err := strconv.ParseInt(strings.TrimSpace(part), 10, 64)
		if err == nil && id > 0 {
			ids = append(ids, id)
		}
	}
	return ids
}

func (r *BookingRepository) CreateGeneralBooking(ctx context.Context, target BookingTarget) (*model.BookingQueueResponse, error) {
	ctxData, err := r.loadBookingContext(ctx, target)
	if err != nil {
		return nil, err
	}

	return r.createBookingTx(ctx, ctxData, target)
}

func (r *BookingRepository) loadBookingContext(ctx context.Context, target BookingTarget) (*bookingContext, error) {
	if target.PatientID <= 0 {
		return nil, errors.New("pasien tidak valid")
	}
	if target.PoliID <= 0 {
		return nil, errors.New("poli tidak valid")
	}

	var (
		poliName  string
		poliBPJS  string
		poliType  sql.NullString
		groupName sql.NullString
		doctorID  sql.NullString
	)

	if err := r.DB.QueryRowContext(ctx, `
		SELECT COALESCE(nama, ''), COALESCE(bpjs, ''), COALESCE(politype, ''), COALESCE(kelompok, ''), COALESCE(dokter_id, '')
		FROM polis
		WHERE id = ?
		LIMIT 1
	`, target.PoliID).Scan(&poliName, &poliBPJS, &poliType, &groupName, &doctorID); err != nil {
		return nil, err
	}

	queueDate := target.Tanggal
	if queueDate.IsZero() {
		queueDate = time.Now()
	}
	queueDate = time.Date(queueDate.Year(), queueDate.Month(), queueDate.Day(), 0, 0, 0, 0, queueDate.Location())

	serviceMode := "umum"
	if target.IsJkn {
		serviceMode = "jkn"
	}

	queueGroupValue := coalesceBookingString(target.QueueGroup, groupName.String, firstCSVValue(doctorID.String), poliType.String)
	if queueGroupValue == "" {
		queueGroupValue = poliName
	}

	return &bookingContext{
		poliID:      target.PoliID,
		poliName:    poliName,
		poliBPJS:    poliBPJS,
		doctorID:    coalesceBookingString(target.DoctorID, firstCSVValue(doctorID.String)),
		queueGroup:  queueGroupValue,
		queueDate:   queueDate,
		serviceMode: serviceMode,
	}, nil
}

func (r *BookingRepository) createBookingTx(ctx context.Context, ctxData *bookingContext, target BookingTarget) (ret *model.BookingQueueResponse, err error) {
	conn, err := r.DB.Conn(ctx)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	tx, err := conn.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead})
	if err != nil {
		return nil, err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	if existing, existingErr := r.findExistingGeneralBookingTx(ctx, tx, target.PatientID, ctxData.poliID, ctxData.queueDate); existingErr == nil && existing != nil {
		existing.Existing = true
		if err = tx.Commit(); err != nil {
			return nil, err
		}
		return existing, nil
	} else if existingErr != nil && !errors.Is(existingErr, sql.ErrNoRows) {
		return nil, existingErr
	}

	lockName := fmt.Sprintf("mobile_booking_queue:%d:%s", ctxData.poliID, ctxData.queueDate.Format("2006-01-02"))
	if err = acquireMySQLLock(ctx, tx, lockName); err != nil {
		return nil, err
	}
	defer func() {
		_, _ = conn.ExecContext(ctx, `SELECT RELEASE_LOCK(?)`, lockName)
	}()

	nextQueueNumber, err := r.nextQueueNumberTx(ctx, tx, ctxData.poliID, ctxData.queueDate)
	if err != nil {
		return nil, err
	}

	regID := generateBookingRegistrationCode(ctxData.queueDate, target.PatientID, ctxData.poliID)
	queueNumber := strconv.Itoa(nextQueueNumber)
	queueCode := formatGeneralQueueCode(nextQueueNumber)
	queueDateString := ctxData.queueDate.Format("2006-01-02")
	jenisPasien := coalesceBookingString(target.JenisPasien, ctxData.serviceMode)
	bayar := coalesceBookingString(target.Bayar, "2")
	jknFlag := "N"
	if ctxData.serviceMode == "jkn" {
		jknFlag = "Y"
	}
	jknNumber := ""
	if ctxData.serviceMode == "jkn" {
		jknNumber = queueNumber
	}

	regResult, err := tx.ExecContext(ctx, `
		INSERT INTO registrasis (
			pasien_id,
			reg_id,
			nomorantrian,
			nomorantrian_jkn,
			jenis_pasien,
			status,
			kasus,
			keterangan,
			dokter_id,
			poli_id,
			bayar,
			tipe_layanan,
			jkn,
			no_jkn,
			input_from,
			created_at,
			updated_at,
			tgl_order
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
	`,
		target.PatientID,
		regID,
		queueNumber,
		jknNumber,
		jenisPasien,
		"baru",
		"1",
		"Booking antrian umum",
		ctxData.doctorID,
		ctxData.poliID,
		bayar,
		jenisPasien,
		jknFlag,
		jknNumber,
		"mobile",
		queueDateString,
	)
	if err != nil {
		return nil, err
	}

	registrationID, err := regResult.LastInsertId()
	if err != nil {
		return nil, err
	}

	queueResult, err := tx.ExecContext(ctx, `
		INSERT INTO antrian_poli (
			registrasi_id,
			antrian_id,
			nomor,
			suara,
			status,
			panggil,
			tanggal,
			loket,
			poli_id,
			kelompok,
			sudah_dipanggil,
			created_at,
			updated_at
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
	`,
		registrationID,
		nil,
		nextQueueNumber,
		fmt.Sprintf("%02d", nextQueueNumber),
		"0",
		"0",
		queueDateString,
		nil,
		ctxData.poliID,
		coalesceBookingString(ctxData.queueGroup, ctxData.poliName),
		0,
	)
	if err != nil {
		return nil, err
	}

	queueID, err := queueResult.LastInsertId()
	if err != nil {
		return nil, err
	}

	if _, err = tx.ExecContext(ctx, `
		UPDATE registrasis
		SET antrian_poli_id = ?, updated_at = NOW()
		WHERE id = ?
	`, queueID, registrationID); err != nil {
		return nil, err
	}

	if err = tx.Commit(); err != nil {
		return nil, err
	}

	return &model.BookingQueueResponse{
		RegistrationID:   registrationID,
		QueueID:          queueID,
		RegistrationCode: regID,
		QueueNumber:      queueNumber,
		QueueCode:        queueCode,
		QueueGroup:       coalesceBookingString(ctxData.queueGroup, ctxData.poliName),
		PoliID:           ctxData.poliID,
		PoliName:         ctxData.poliName,
		QueueDate:        queueDateString,
		ServiceMode:      ctxData.serviceMode,
	}, nil
}

func (r *BookingRepository) ListGeneralBookings(ctx context.Context, filter BookingListFilter) (*model.MobileBookingListResponse, error) {
	limit := normalizeBookingLimit(filter.Limit)
	args := []any{}
	conditions := []string{
		"r.deleted_at IS NULL",
		"r.input_from = 'mobile'",
		"(r.jkn IS NULL OR r.jkn <> 'Y')",
	}

	if filter.PatientID > 0 {
		conditions = append(conditions, "r.pasien_id = ?")
		args = append(args, filter.PatientID)
	}

	if filter.Date != nil {
		conditions = append(conditions, "r.tgl_order = ?")
		args = append(args, filter.Date.Format("2006-01-02"))
	}

	status := strings.ToLower(strings.TrimSpace(filter.Status))
	if status != "" && status != "semua" && status != "all" {
		conditions = append(conditions, bookingStatusCondition())
		args = append(args, status, status, status, status, status, status, status, status, status)
	}

	query := fmt.Sprintf(`
	SELECT
		r.id,
		COALESCE(a.id, 0),
		COALESCE(r.reg_id, ''),
		COALESCE(NULLIF(r.nomorantrian, ''), COALESCE(CAST(a.nomor AS CHAR), '')),
		COALESCE(a.nomor, 0),
		COALESCE(a.kelompok, ''),
		COALESCE(DATE_FORMAT(r.tgl_order, '%%Y-%%m-%%d'), DATE_FORMAT(a.tanggal, '%%Y-%%m-%%d'), DATE_FORMAT(r.created_at, '%%Y-%%m-%%d'), ''),
		COALESCE(DATE_FORMAT(r.created_at, '%%Y-%%m-%%d %%H:%%i'), ''),
		COALESCE(r.status, ''),
		COALESCE(r.status_reg, ''),
		COALESCE(a.status, ''),
		COALESCE(a.panggil, ''),
		COALESCE(a.sudah_dipanggil, 0),
		p.id,
		COALESCE(p.no_rm, ''),
		COALESCE(p.nama, ''),
		COALESCE(po.id, 0),
		COALESCE(po.nama, ''),
		COALESCE(d.id, 0),
		COALESCE(d.nama, ''),
		COALESCE(r.input_from, ''),
		COALESCE(r.jenis_pasien, ''),
		COALESCE(r.bayar, ''),
		COALESCE(r.keterangan, '')
	FROM registrasis r
	INNER JOIN pasiens p ON p.id = r.pasien_id
	LEFT JOIN antrian_poli a ON a.id = r.antrian_poli_id
	LEFT JOIN polis po ON po.id = r.poli_id
	LEFT JOIN pegawais d ON d.id = CAST(r.dokter_id AS UNSIGNED)
	WHERE %s
	ORDER BY r.tgl_order DESC, r.id DESC
	LIMIT ?
	`, strings.Join(conditions, "\n\tAND "))
	args = append(args, limit)

	rows, err := r.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	items := make([]model.MobileBookingRecord, 0)
	counts := map[string]int{}

	for rows.Next() {
		var record model.MobileBookingRecord
		var numericQueue int64
		var alreadyCalled int
		if err = rows.Scan(
			&record.RegistrationID,
			&record.QueueID,
			&record.RegistrationCode,
			&record.QueueNumber,
			&numericQueue,
			&record.QueueGroup,
			&record.QueueDate,
			&record.CreatedAt,
			&record.RegistrationStatus,
			&record.StatusReg,
			&record.QueueStatus,
			&record.CallStatus,
			&alreadyCalled,
			&record.PatientID,
			&record.NoRM,
			&record.PatientName,
			&record.PoliID,
			&record.PoliName,
			&record.DoctorID,
			&record.DoctorName,
			&record.InputFrom,
			&record.PatientType,
			&record.PaymentType,
			&record.Note,
		); err != nil {
			return nil, err
		}

		record.AlreadyCalled = alreadyCalled > 0
		if record.QueueNumber == "" && numericQueue > 0 {
			record.QueueNumber = strconv.FormatInt(numericQueue, 10)
		}
		if numericQueue > 0 {
			record.QueueCode = formatGeneralQueueCode(int(numericQueue))
		} else {
			record.QueueCode = record.QueueNumber
		}
		record.QueueStatusLabel = bookingStatusLabel(record.QueueStatus, record.CallStatus, record.AlreadyCalled, record.StatusReg)
		counts[record.QueueStatusLabel]++
		items = append(items, record)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return &model.MobileBookingListResponse{
		Items:        items,
		StatusCounts: bookingStatusCounts(counts),
	}, nil
}

func (r *BookingRepository) nextQueueNumberTx(ctx context.Context, tx *sql.Tx, poliID int64, queueDate time.Time) (int, error) {
	var next sql.NullInt64
	if err := tx.QueryRowContext(ctx, `
		SELECT COALESCE(MAX(nomor), 0) + 1
		FROM antrian_poli
		WHERE poli_id = ?
		AND tanggal = ?
	`, poliID, queueDate.Format("2006-01-02")).Scan(&next); err != nil {
		return 0, err
	}

	if next.Valid && next.Int64 > 0 {
		return int(next.Int64), nil
	}

	return 1, nil
}

func (r *BookingRepository) findExistingGeneralBookingTx(ctx context.Context, tx *sql.Tx, patientID int64, poliID int64, queueDate time.Time) (*model.BookingQueueResponse, error) {
	var response model.BookingQueueResponse
	var numericQueue int64
	if err := tx.QueryRowContext(ctx, `
		SELECT
			r.id,
			COALESCE(a.id, 0),
			COALESCE(r.reg_id, ''),
			COALESCE(NULLIF(r.nomorantrian, ''), COALESCE(CAST(a.nomor AS CHAR), '')),
			COALESCE(a.nomor, 0),
			COALESCE(a.kelompok, ''),
			COALESCE(r.poli_id, 0),
			COALESCE(po.nama, ''),
			COALESCE(DATE_FORMAT(r.tgl_order, '%Y-%m-%d'), DATE_FORMAT(a.tanggal, '%Y-%m-%d'), DATE_FORMAT(r.created_at, '%Y-%m-%d'), '')
		FROM registrasis r
		LEFT JOIN antrian_poli a ON a.id = r.antrian_poli_id
		LEFT JOIN polis po ON po.id = r.poli_id
		WHERE r.pasien_id = ?
		AND r.poli_id = ?
		AND r.input_from = 'mobile'
		AND (r.jkn IS NULL OR r.jkn <> 'Y')
		AND r.deleted_at IS NULL
		AND r.tgl_order = ?
		ORDER BY r.id DESC
		LIMIT 1
		FOR UPDATE
	`, patientID, poliID, queueDate.Format("2006-01-02")).Scan(
		&response.RegistrationID,
		&response.QueueID,
		&response.RegistrationCode,
		&response.QueueNumber,
		&numericQueue,
		&response.QueueGroup,
		&response.PoliID,
		&response.PoliName,
		&response.QueueDate,
	); err != nil {
		return nil, err
	}

	if response.QueueNumber == "" && numericQueue > 0 {
		response.QueueNumber = strconv.FormatInt(numericQueue, 10)
	}
	if numericQueue > 0 {
		response.QueueCode = formatGeneralQueueCode(int(numericQueue))
	} else {
		response.QueueCode = response.QueueNumber
	}
	response.ServiceMode = "umum"

	return &response, nil
}

func acquireMySQLLock(ctx context.Context, tx *sql.Tx, lockName string) error {
	var lockStatus sql.NullInt64
	if err := tx.QueryRowContext(ctx, `SELECT GET_LOCK(?, 10)`, lockName).Scan(&lockStatus); err != nil {
		return err
	}
	if !lockStatus.Valid || lockStatus.Int64 != 1 {
		return errors.New("gagal mengunci nomor antrian, silakan coba lagi")
	}
	return nil
}

func generateBookingRegistrationCode(queueDate time.Time, patientID int64, poliID int64) string {
	return fmt.Sprintf("%s%03d%03d", queueDate.Format("20060102"), patientID%1000, poliID%1000)
}

func coalesceBookingString(values ...string) string {
	for _, value := range values {
		trimmed := strings.TrimSpace(value)
		if trimmed != "" && trimmed != "-" {
			return trimmed
		}
	}
	return ""
}

func firstCSVValue(value string) string {
	for _, part := range strings.Split(value, ",") {
		trimmed := strings.TrimSpace(part)
		if trimmed != "" && trimmed != "-" {
			return trimmed
		}
	}
	return ""
}

func formatGeneralQueueCode(queueNumber int) string {
	if queueNumber <= 0 {
		return ""
	}
	return fmt.Sprintf("U-%03d", queueNumber)
}

func normalizeBookingLimit(limit int) int {
	if limit < 1 {
		return 50
	}
	if limit > 200 {
		return 200
	}
	return limit
}

func bookingStatusCondition() string {
	return `(
		LOWER(COALESCE(r.status, '')) = ?
		OR LOWER(COALESCE(r.status_reg, '')) = ?
		OR LOWER(COALESCE(a.status, '')) = ?
		OR LOWER(COALESCE(a.panggil, '')) = ?
		OR (? = 'menunggu' AND (a.id IS NULL OR COALESCE(a.status, '0') = '0') AND COALESCE(a.panggil, '0') = '0' AND COALESCE(a.sudah_dipanggil, 0) = 0)
		OR (? = 'dipanggil' AND (COALESCE(a.panggil, '0') = '1' OR COALESCE(a.sudah_dipanggil, 0) = 1))
		OR (? = 'selesai' AND COALESCE(a.status, '') = '2')
		OR (? = 'batal' AND LOWER(COALESCE(r.batal, '')) IN ('1', 'y', 'ya', 'true'))
		OR (? = 'mobile' AND COALESCE(r.input_from, '') = 'mobile')
	)`
}

func bookingStatusLabel(queueStatus string, callStatus string, alreadyCalled bool, statusReg string) string {
	normalizedQueueStatus := strings.ToLower(strings.TrimSpace(queueStatus))
	normalizedCallStatus := strings.ToLower(strings.TrimSpace(callStatus))
	normalizedStatusReg := strings.ToLower(strings.TrimSpace(statusReg))

	if normalizedQueueStatus == "2" || normalizedStatusReg == "selesai" {
		return "selesai"
	}
	if normalizedCallStatus == "1" || alreadyCalled || normalizedQueueStatus == "1" {
		return "dipanggil"
	}
	if normalizedStatusReg != "" && normalizedStatusReg != "-" && normalizedStatusReg != "0" {
		return normalizedStatusReg
	}
	return "menunggu"
}

func bookingStatusCounts(counts map[string]int) []model.MobileBookingStatusCount {
	order := []string{"menunggu", "dipanggil", "selesai", "batal"}
	results := make([]model.MobileBookingStatusCount, 0, len(counts))
	seen := map[string]bool{}

	for _, status := range order {
		count, ok := counts[status]
		if !ok {
			continue
		}
		results = append(results, model.MobileBookingStatusCount{Status: status, Count: count})
		seen[status] = true
	}

	for status, count := range counts {
		if seen[status] {
			continue
		}
		results = append(results, model.MobileBookingStatusCount{Status: status, Count: count})
	}

	return results
}
