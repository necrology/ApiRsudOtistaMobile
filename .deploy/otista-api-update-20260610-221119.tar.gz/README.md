# ApiRsudOtistaMobile

API RSUD Otista Mobile menggunakan Go Fiber dan MySQL.

## Arsitektur

- `cmd/api`: entry point aplikasi Go.
- `internal/config`: konfigurasi environment.
- `internal/database`: koneksi MySQL dan migrasi auth mobile.
- `internal/http/handlers`: handler endpoint.
- `internal/http/routes`: registrasi route.
- `internal/repository`: query data MySQL.
- `database`: schema import awal.
- `historyQuery/history.sql`: catatan alter dan DDL tambahan yang harus diikuti saat perubahan skema.

## Database Produksi

Aplikasi ini membaca database `rsud_otista`.
Di server runtime yang saya cek, MySQL container/service diekspos lewat host lokal `127.0.0.1:33061` dan user `root` dengan password dari `.env` source Go.

Tabel inti yang dipakai fitur mobile:

- `pasiens`: master pasien.
- `user_mobile`: akun mobile dan relasi ke pasien lewat `patient_id`.
- `polis`: master poli dan jam layanan.
- `pegawais`: master dokter/pegawai.
- `registrasis`: pusat transaksi pendaftaran/kunjungan.
- `antrian_poli`: nomor antrian poli dan status panggil.
- `resume_pasiens`, `hasillabs`, `order_lab`, `order_radiologi`, `radiologi_ekspertises`: data riwayat dan hasil pemeriksaan.

Relasi booking umum yang dipakai endpoint baru:

- `user_mobile.patient_id -> pasiens.id`
- `registrasis.pasien_id -> pasiens.id`
- `registrasis.poli_id -> polis.id`
- `registrasis.dokter_id -> pegawais.id` dalam bentuk string ID.
- `registrasis.antrian_poli_id -> antrian_poli.id`
- `antrian_poli.registrasi_id -> registrasis.id`

## Endpoint Baru

Booking umum:

```text
POST /api/v1/mobile/booking/general
```

Request body contoh:

```json
{
  "identifier": "user@email.com",
  "email": "user@email.com",
  "no_rm": "RM000001",
  "poli_id": 27,
  "tanggal": "2026-06-08",
  "bayar": "2",
  "jenis_pasien": "umum",
  "dokter_id": "42",
  "queue_group": "HDLO",
  "is_jkn": false
}
```

Respons booking:

- `registration_id`
- `queue_id`
- `registration_code`
- `queue_number`
- `queue_group`
- `poli_id`
- `poli_name`
- `queue_date`
- `service_mode`

BPJS tidak dibuat sebagai booking internal. Aplikasi mobile diarahkan ke Mobile JKN via launcher Android dan fallback Play Store.

## Menjalankan Lokal

1. Pastikan MySQL XAMPP aktif atau gunakan database produksi yang terhubung lewat `.env`.
2. Jalankan schema import bila database baru:

```powershell
& 'C:\xampp\mysql\bin\mysql.exe' --local-infile=1 -u root --execute="source database/mysql_schema_import.sql"
```

3. Salin `.env.example` menjadi `.env` lalu sesuaikan koneksi MySQL, SMTP, dan port.
4. Jalankan API:

```powershell
go run ./cmd/api
```

Endpoint yang tersedia:

```text
GET  /api/v1/health
GET  /api/v1/tables
GET  /api/v1/tables/:table
GET  /api/v1/tables/:table/search
GET  /api/v1/:table
GET  /api/v1/:table/search
GET  /api/v1/:table/:id
POST /api/v1/mobile/booking/general
GET  /api/v1/mobile/patient/profile
GET  /api/v1/mobile/patient/visits
GET  /api/v1/mobile/patient/medical-summaries
GET  /api/v1/mobile/patient/laboratory-results
GET  /api/v1/mobile/patient/radiology-results
POST /api/v1/auth/register
POST /api/v1/auth/login
POST /api/v1/auth/verify-otp
POST /api/v1/auth/verify-otp-new-user
POST /api/v1/auth/set-password
POST /api/v1/auth/forgot-password
POST /api/v1/auth/reset-password
POST /api/v1/auth/medical-record/request
POST /api/v1/auth/medical-record/confirm
```

## Deploy Produksi

### 1. Siapkan environment

Buat file `.env` pada server produksi dengan isi yang sesuai:

```env
APP_NAME=ApiRsudOtistaMobile
APP_ENV=production
APP_PORT=8080
DB_HOST=127.0.0.1
DB_PORT=33061
DB_USER=root
DB_PASSWORD=...
DB_NAME=rsud_otista
SMTP_HOST=...
SMTP_PORT=587
SMTP_EMAIL=...
SMTP_PASSWORD=...
```

Jika MySQL berada di container internal, pastikan host/port yang dipakai bisa dijangkau dari proses API. Pada server yang saya cek, port `33061` adalah mapping yang bisa dipakai dari host.

### 2. Sinkronkan database

Jalankan schema import awal bila database belum ada:

```powershell
mysql -h 127.0.0.1 -P 33061 -u root -p < database/mysql_schema_import.sql
```

Lalu jalankan catatan alter dari `historyQuery/history.sql` secara berurutan untuk memastikan skema auth mobile dan booking umum sama dengan code.

### 3. Build dan run

```powershell
go build -o bin/otista-api-dev ./cmd/api
./bin/otista-api-dev
```

Atau jalankan sebagai service/container bila server produksi memang memakai Docker.

### 4. Verifikasi

- `GET /api/v1/health`
- `GET /api/v1/tables`
- `POST /api/v1/mobile/booking/general`
- `GET /api/v1/mobile/patient/visits`

### 5. Catatan produksi

- Booking umum harus memakai transaksi database agar `registrasis` dan `antrian_poli` selalu sinkron.
- BPJS tetap diarahkan ke Mobile JKN, bukan dibuat booking internal ganda.
- Setiap perubahan skema harus dicatat di `historyQuery/history.sql` supaya deployment prod tidak kehilangan jejak.

## Docker

Project ini sudah bisa dijalankan sebagai dua service Docker:

- `api`: aplikasi Go Fiber pada port internal `8080`.
- `mysql`: database MySQL dengan volume persistent `otista_mysql_data`.

Untuk menyiapkan dump database dari XAMPP lokal:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\export_mysql_dump.ps1
```

Lalu jalankan:

```powershell
copy .env.docker.example .env
docker compose up -d --build
```

Endpoint container API tersedia di host pada `127.0.0.1:8080`, sehingga bisa diarahkan dari Cloudflare Tunnel ke `http://localhost:8080`.