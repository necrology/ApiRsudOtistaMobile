package auth

import (
	"crypto/rand"
	"errors"
	"fmt"
	"log"
	"math/big"
	"net/mail"
	"strings"
	"time"
	"unicode"

	"apirusdotistamobile/internal/config"
	"apirusdotistamobile/internal/model"
	"apirusdotistamobile/internal/repository"

	"golang.org/x/crypto/bcrypt"
)

type Service struct {
	Repo *repository.AuthRepository
	SMTP config.SMTPConfig
}

func NewService(
	repo *repository.AuthRepository,
	smtp config.SMTPConfig,
) *Service {

	return &Service{
		Repo: repo,
		SMTP: smtp,
	}
}

func (s *Service) RegisterUser(
	req model.RegisterRequest,
) error {
	req.Username = strings.TrimSpace(req.Username)
	email, err := normalizeEmail(req.Email)
	if err != nil {
		return errors.New("email tidak valid")
	}
	req.Email = email
	req.NoRM = ""
	req.Phone = strings.TrimSpace(req.Phone)
	req.FullName = strings.TrimSpace(req.FullName)

	if req.Username == "" && req.FullName != "" {
		req.Username = req.FullName
	}

	if req.Username == "" || req.Email == "" {

		return errors.New(
			"username and email are required",
		)
	}

	if err := validatePassword(req.Password); err != nil {
		return err
	}

	existingUser, _ := s.Repo.FindByUsername(
		req.Username,
	)

	if existingUser != nil {
		return errors.New(
			"username already exists",
		)
	}
	existingEmail, _ := s.Repo.FindUserByEmail(req.Email)

	if existingEmail != nil {
		return errors.New(
			"email already exists",
		)
	}

	otp := GenerateOTP()

	err = s.Repo.CreateVerifEmail(
		model.User{
			Username: req.Username,
			Email:    req.Email,
			NoRM:     req.NoRM,
			Phone:    req.Phone,
			FullName: req.FullName,
		},
		otp,
	)

	if err != nil {
		return err
	}

	err = SendOTPEmailWithPurpose(
		s.SMTP,
		req.Email,
		otp,
		"Verifikasi Email RSUD Otista Mobile",
		"verifikasi email akun RSUD Otista Mobile",
	)

	if err != nil {
		return err
	}

	return nil
}

func (s *Service) VerifyOTPNewUser(
	req model.VerifyOTPNewUser,
) error {
	email, err := normalizeEmail(req.Email)
	if err != nil {
		return errors.New("Email not found")
	}

	user, err := s.Repo.FindByEmailNewUser(
		email,
	)

	if err != nil {
		return errors.New("Email not found")
	}

	valid, err := s.Repo.VerifyOTPNewUser(
		user.Email,
		req.OTP,
	)

	if err != nil || !valid {
		return errors.New("invalid otp")
	}

	return nil
}

func (s *Service) SetPassword(
	req model.SetPasswordRequest,
) (*model.User, error) {
	email, err := normalizeEmail(req.Email)
	if err != nil {
		return nil, errors.New("email not verified")
	}

	if err := validatePassword(req.Password); err != nil {
		return nil, err
	}

	existingUser, _ := s.Repo.FindUserByEmail(email)
	if existingUser != nil {
		return nil, errors.New("email already exists")
	}

	data, err := s.Repo.FindVerifiedEmail(
		email,
	)

	if err != nil {
		return nil, errors.New("email not verified")
	}

	hash, err := bcrypt.GenerateFromPassword(
		[]byte(req.Password),
		bcrypt.DefaultCost,
	)

	if err != nil {
		return nil, err
	}

	user := model.User{
		Username: data.Username,
		Email:    data.Email,
		NoRM:     data.NoRM,
		Phone:    data.Phone,
		FullName: data.FullName,
		Password: string(hash),
	}

	if err = s.Repo.Create(user); err != nil {
		return nil, err
	}

	return s.Repo.FindUserByEmail(data.Email)
}

func (s *Service) Login(req model.LoginRequest) error {
	user, err := s.resolveLoginUser(req.Identifier, req.Email, req.NoRM, req.Username)
	if err != nil {
		return err
	}

	// cek password dulu
	err = bcrypt.CompareHashAndPassword(
		[]byte(user.Password),
		[]byte(req.Password),
	)

	if err != nil {
		return errors.New("email atau password tidak sesuai")
	}

	// baru OTP
	if user.EmailVerified {

		otp := GenerateOTP()

		err = s.Repo.CreateOTPLogin(
			user.ID,
			otp,
		)

		if err != nil {
			return err
		}

		err = SendOTPEmailWithPurpose(
			s.SMTP,
			user.Email,
			otp,
			"Kode OTP Login RSUD Otista Mobile",
			"login ke RSUD Otista Mobile",
		)

		if err != nil {
			return err
		}

		return nil
	}

	return errors.New("email not verified")
}
func (s *Service) VerifyEmail(token string) error {

	return s.Repo.VerifyEmail(token)
}
func GenerateOTP() string {
	value, err := rand.Int(rand.Reader, big.NewInt(1000000))
	if err != nil {
		return "000000"
	}

	return fmt.Sprintf("%06d", value.Int64())
}

func (s *Service) VerifyOTPLogin(
	req model.VerifyOTPRequestLogin,
) (*model.User, error) {
	user, err := s.resolveLoginUser(req.Identifier, req.Email, req.Username)
	if err != nil {
		return nil, errors.New("invalid otp")
	}

	valid, err := s.Repo.VerifyOTPLogin(
		user.ID,
		req.OTP,
	)

	if err != nil || !valid {
		return nil, errors.New("invalid otp")
	}

	return user, nil
}

func (s *Service) ForgotPassword(req model.ForgotPasswordRequest) error {
	identifier, err := normalizeEmailIdentifier(req.Identifier, req.Email)
	if err != nil {
		return errors.New("email is required")
	}

	user, err := s.Repo.FindByIdentifier(identifier)
	if err != nil {
		return nil
	}

	otp := GenerateOTP()
	if err = s.Repo.CreatePasswordResetOTP(user.ID, otp); err != nil {
		return err
	}

	go func() {
		if err := SendOTPEmailWithPurpose(
			s.SMTP,
			user.Email,
			otp,
			"Reset Password RSUD Otista Mobile",
			"mengatur ulang password akun RSUD Otista Mobile",
		); err != nil {
			log.Printf("send password reset otp email failed for user %d: %v", user.ID, err)
		}
	}()

	return nil
}

func (s *Service) ResetPassword(req model.ResetPasswordRequest) error {
	identifier, emailErr := normalizeEmailIdentifier(req.Identifier, req.Email)

	if emailErr != nil || strings.TrimSpace(req.OTP) == "" || strings.TrimSpace(req.Password) == "" {
		return errors.New("email, otp, and password are required")
	}

	if err := validatePassword(req.Password); err != nil {
		return err
	}

	user, err := s.Repo.FindByIdentifier(identifier)
	if err != nil {
		return errors.New("invalid otp")
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	valid, err := s.Repo.ResetPassword(user.ID, strings.TrimSpace(req.OTP), string(hash))
	if err != nil || !valid {
		return errors.New("invalid otp")
	}

	return nil
}

func (s *Service) RequestMedicalRecordClaim(
	req model.RequestMedicalRecordClaim,
) error {
	email, err := normalizeEmail(req.Email)
	if err != nil {
		return errors.New("akun belum valid untuk mengubah no rm")
	}

	password := strings.TrimSpace(req.Password)
	noRM := strings.TrimSpace(req.NoRM)
	nik := normalizeDigits(req.NIK)
	birthDate, err := normalizeBirthDate(req.BirthDate)
	if err != nil {
		return errors.New("data rekam medis tidak cocok atau tidak bisa digunakan")
	}

	if email == "" || password == "" || noRM == "" || nik == "" {
		return errors.New("data rekam medis tidak cocok atau tidak bisa digunakan")
	}

	if len(nik) != 16 {
		return errors.New("data rekam medis tidak cocok atau tidak bisa digunakan")
	}

	user, err := s.Repo.FindUserByEmail(email)
	if err != nil || !user.EmailVerified {
		return errors.New("akun belum valid untuk mengubah no rm")
	}

	if err = bcrypt.CompareHashAndPassword(
		[]byte(user.Password),
		[]byte(password),
	); err != nil {
		return errors.New("akun belum valid untuk mengubah no rm")
	}

	patient, err := s.Repo.FindPatientByMedicalRecordClaim(
		noRM,
		nik,
		birthDate,
	)
	if err != nil {
		return errors.New("data rekam medis tidak cocok atau tidak bisa digunakan")
	}

	linked, err := s.Repo.IsPatientLinkedToAnotherUser(patient.ID, user.ID)
	if err != nil {
		return err
	}
	if linked {
		return errors.New("data rekam medis tidak cocok atau tidak bisa digunakan")
	}

	otp := GenerateOTP()
	if err = s.Repo.CreateMedicalRecordClaimOTP(user.ID, *patient, otp); err != nil {
		return err
	}

	return SendOTPEmailWithPurpose(
		s.SMTP,
		user.Email,
		otp,
		"Verifikasi No. RM RSUD Otista Mobile",
		"menghubungkan No. RM ke akun RSUD Otista Mobile",
	)
}

func (s *Service) ConfirmMedicalRecordClaim(
	req model.ConfirmMedicalRecordClaim,
) (*model.User, error) {
	email, err := normalizeEmail(req.Email)
	if err != nil {
		return nil, errors.New("otp klaim no rm tidak valid")
	}
	otp := strings.TrimSpace(req.OTP)
	if email == "" || otp == "" {
		return nil, errors.New("otp klaim no rm tidak valid")
	}

	user, valid, err := s.Repo.ConfirmMedicalRecordClaim(email, otp)
	if err != nil || !valid {
		return nil, errors.New("otp klaim no rm tidak valid")
	}

	return user, nil
}

func normalizeDigits(value string) string {
	var builder strings.Builder
	for _, char := range value {
		if unicode.IsDigit(char) {
			builder.WriteRune(char)
		}
	}

	return builder.String()
}

func (s *Service) resolveLoginUser(values ...string) (*model.User, error) {
	identifier := firstNonEmpty(values...)
	if identifier == "" {
		return nil, errors.New("email atau no rm wajib diisi")
	}

	if email, err := normalizeEmail(identifier); err == nil {
		user, err := s.Repo.FindUserByEmail(email)
		if err != nil {
			return nil, errors.New("email atau password tidak sesuai")
		}
		return user, nil
	}

	user, err := s.Repo.FindLinkedUserByNoRM(normalizeMedicalRecordNumber(identifier))
	if err == nil {
		return user, nil
	}
	if errors.Is(err, repository.ErrNoRMNotLinked) {
		return nil, errors.New("No. RM belum terhubung ke akun mobile. Silakan login dengan email lalu hubungkan No. RM di profil.")
	}
	if errors.Is(err, repository.ErrNoRMAmbiguous) {
		return nil, errors.New("No. RM terhubung ke lebih dari satu akun. Silakan login dengan email.")
	}

	return nil, errors.New("email atau password tidak sesuai")
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" {
			return value
		}
	}

	return ""
}

func normalizeMedicalRecordNumber(value string) string {
	return strings.ToUpper(strings.TrimSpace(value))
}

func normalizeEmailIdentifier(values ...string) (string, error) {
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		return normalizeEmail(value)
	}

	return "", errors.New("email is required")
}

func normalizeEmail(value string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return "", errors.New("email is required")
	}

	address, err := mail.ParseAddress(value)
	if err != nil || address.Address == "" {
		return "", errors.New("invalid email")
	}

	return strings.ToLower(address.Address), nil
}

func validatePassword(password string) error {
	password = strings.TrimSpace(password)
	if len(password) < 8 {
		return errors.New("password minimal 8 karakter")
	}

	hasLetter := false
	hasDigit := false
	for _, char := range password {
		if unicode.IsLetter(char) {
			hasLetter = true
		}
		if unicode.IsDigit(char) {
			hasDigit = true
		}
	}

	if !hasLetter || !hasDigit {
		return errors.New("password harus berisi huruf dan angka")
	}

	return nil
}

func normalizeBirthDate(value string) (string, error) {
	value = strings.TrimSpace(value)
	for _, layout := range []string{"2006-01-02", "02-01-2006", "02/01/2006"} {
		parsed, err := time.Parse(layout, value)
		if err == nil {
			return parsed.Format("2006-01-02"), nil
		}
	}

	return "", errors.New("invalid birth date")
}
