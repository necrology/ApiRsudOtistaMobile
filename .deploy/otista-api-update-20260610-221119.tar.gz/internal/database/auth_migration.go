package database

import (
	"database/sql"
	"fmt"
)

func EnsureAuthSchema(db *sql.DB, schema string) error {
	if err := renameLegacyMobileAuthTables(db, schema); err != nil {
		return err
	}

	statements := []string{
		`CREATE TABLE IF NOT EXISTS user_mobile (
			id BIGINT AUTO_INCREMENT PRIMARY KEY,
			username VARCHAR(100) NOT NULL,
			email VARCHAR(100) NOT NULL,
			no_rm VARCHAR(20) NULL,
			patient_id BIGINT UNSIGNED NULL,
			phone VARCHAR(30) NULL,
			full_name VARCHAR(150) NULL,
			password VARCHAR(255) NOT NULL,
			email_verified BOOLEAN DEFAULT FALSE,
			verification_token VARCHAR(255) NULL,
			verified_at TIMESTAMP NULL DEFAULT NULL,
			medical_record_verified_at TIMESTAMP NULL DEFAULT NULL,
			is_deleted BOOLEAN DEFAULT FALSE,
			deleted_at TIMESTAMP NULL DEFAULT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			UNIQUE KEY uk_user_email (email),
			KEY idx_user_mobile_no_rm (no_rm),
			UNIQUE KEY uk_user_patient_id (patient_id)
		)`,
		`CREATE TABLE IF NOT EXISTS otp_user_mobile (
			id BIGINT AUTO_INCREMENT PRIMARY KEY,
			user_id BIGINT NOT NULL,
			otp_code VARCHAR(10) NOT NULL,
			expired_at TIMESTAMP NOT NULL,
			is_used BOOLEAN DEFAULT FALSE,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			FOREIGN KEY (user_id) REFERENCES user_mobile(id) ON DELETE CASCADE
		)`,
		`CREATE TABLE IF NOT EXISTS otp_verif_email_mobile (
			id BIGINT AUTO_INCREMENT PRIMARY KEY,
			username VARCHAR(100) NOT NULL,
			email VARCHAR(100) NOT NULL,
			no_rm VARCHAR(20) NULL,
			phone VARCHAR(30) NULL,
			full_name VARCHAR(150) NULL,
			otp_code VARCHAR(10) NOT NULL,
			expired_at TIMESTAMP NOT NULL,
			is_used BOOLEAN DEFAULT FALSE,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
		)`,
		`CREATE TABLE IF NOT EXISTS otp_password_reset_mobile (
			id BIGINT AUTO_INCREMENT PRIMARY KEY,
			user_id BIGINT NOT NULL,
			otp_code VARCHAR(10) NOT NULL,
			expired_at TIMESTAMP NOT NULL,
			is_used BOOLEAN DEFAULT FALSE,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			FOREIGN KEY (user_id) REFERENCES user_mobile(id) ON DELETE CASCADE
		)`,
		`CREATE TABLE IF NOT EXISTS otp_medical_record_claim_mobile (
			id BIGINT AUTO_INCREMENT PRIMARY KEY,
			user_id BIGINT NOT NULL,
			patient_id BIGINT UNSIGNED NOT NULL,
			no_rm VARCHAR(20) NOT NULL,
			patient_name VARCHAR(150) NULL,
			otp_code VARCHAR(10) NOT NULL,
			expired_at TIMESTAMP NOT NULL,
			is_used BOOLEAN DEFAULT FALSE,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			FOREIGN KEY (user_id) REFERENCES user_mobile(id) ON DELETE CASCADE,
			KEY idx_otp_medical_record_claim_user (user_id),
			KEY idx_otp_medical_record_claim_no_rm (no_rm)
		)`,
	}

	for _, statement := range statements {
		if _, err := db.Exec(statement); err != nil {
			return err
		}
	}

	columns := []struct {
		table  string
		column string
		ddl    string
	}{
		{"user_mobile", "no_rm", "ALTER TABLE `user_mobile` ADD COLUMN `no_rm` VARCHAR(20) NULL AFTER `email`"},
		{"user_mobile", "patient_id", "ALTER TABLE `user_mobile` ADD COLUMN `patient_id` BIGINT UNSIGNED NULL AFTER `no_rm`"},
		{"user_mobile", "phone", "ALTER TABLE `user_mobile` ADD COLUMN `phone` VARCHAR(30) NULL AFTER `patient_id`"},
		{"user_mobile", "full_name", "ALTER TABLE `user_mobile` ADD COLUMN `full_name` VARCHAR(150) NULL AFTER `phone`"},
		{"user_mobile", "email_verified", "ALTER TABLE `user_mobile` ADD COLUMN `email_verified` BOOLEAN DEFAULT FALSE AFTER `password`"},
		{"user_mobile", "verification_token", "ALTER TABLE `user_mobile` ADD COLUMN `verification_token` VARCHAR(255) NULL AFTER `email_verified`"},
		{"user_mobile", "verified_at", "ALTER TABLE `user_mobile` ADD COLUMN `verified_at` TIMESTAMP NULL DEFAULT NULL AFTER `verification_token`"},
		{"user_mobile", "medical_record_verified_at", "ALTER TABLE `user_mobile` ADD COLUMN `medical_record_verified_at` TIMESTAMP NULL DEFAULT NULL AFTER `verified_at`"},
		{"user_mobile", "is_deleted", "ALTER TABLE `user_mobile` ADD COLUMN `is_deleted` BOOLEAN DEFAULT FALSE AFTER `medical_record_verified_at`"},
		{"user_mobile", "deleted_at", "ALTER TABLE `user_mobile` ADD COLUMN `deleted_at` TIMESTAMP NULL DEFAULT NULL AFTER `is_deleted`"},
		{"user_mobile", "created_at", "ALTER TABLE `user_mobile` ADD COLUMN `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER `deleted_at`"},
		{"user_mobile", "updated_at", "ALTER TABLE `user_mobile` ADD COLUMN `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`"},
		{"otp_verif_email_mobile", "no_rm", "ALTER TABLE `otp_verif_email_mobile` ADD COLUMN `no_rm` VARCHAR(20) NULL AFTER `email`"},
		{"otp_verif_email_mobile", "phone", "ALTER TABLE `otp_verif_email_mobile` ADD COLUMN `phone` VARCHAR(30) NULL AFTER `no_rm`"},
		{"otp_verif_email_mobile", "full_name", "ALTER TABLE `otp_verif_email_mobile` ADD COLUMN `full_name` VARCHAR(150) NULL AFTER `phone`"},
	}

	for _, column := range columns {
		if err := ensureColumn(db, schema, column.table, column.column, column.ddl); err != nil {
			return fmt.Errorf("ensure column %s.%s: %w", column.table, column.column, err)
		}
	}

	if err := dropIndexIfExists(db, schema, "user_mobile", "uk_user_no_rm"); err != nil {
		return fmt.Errorf("drop deprecated index user_mobile.uk_user_no_rm: %w", err)
	}

	indexes := []struct {
		table string
		index string
		ddl   string
	}{
		{"user_mobile", "idx_user_mobile_no_rm", "ALTER TABLE `user_mobile` ADD KEY `idx_user_mobile_no_rm` (`no_rm`)"},
		{"user_mobile", "uk_user_patient_id", "ALTER TABLE `user_mobile` ADD UNIQUE KEY `uk_user_patient_id` (`patient_id`)"},
		{"otp_user_mobile", "idx_otp_user_mobile_user_used_expired", "ALTER TABLE `otp_user_mobile` ADD KEY `idx_otp_user_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`)"},
		{"otp_verif_email_mobile", "idx_otp_verif_email_mobile_email_used_expired", "ALTER TABLE `otp_verif_email_mobile` ADD KEY `idx_otp_verif_email_mobile_email_used_expired` (`email`, `is_used`, `expired_at`)"},
		{"otp_password_reset_mobile", "idx_otp_password_reset_mobile_user_used_expired", "ALTER TABLE `otp_password_reset_mobile` ADD KEY `idx_otp_password_reset_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`)"},
		{"otp_medical_record_claim_mobile", "idx_otp_medical_record_claim_mobile_user_used_expired", "ALTER TABLE `otp_medical_record_claim_mobile` ADD KEY `idx_otp_medical_record_claim_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`)"},
	}

	for _, index := range indexes {
		if err := ensureIndex(db, schema, index.table, index.index, index.ddl); err != nil {
			return fmt.Errorf("ensure index %s.%s: %w", index.table, index.index, err)
		}
	}

	return nil
}

func renameLegacyMobileAuthTables(db *sql.DB, schema string) error {
	renames := []struct {
		oldName string
		newName string
	}{
		{"user", "user_mobile"},
		{"otp_user", "otp_user_mobile"},
		{"otp_verif_email", "otp_verif_email_mobile"},
		{"otp_password_reset", "otp_password_reset_mobile"},
		{"otp_medical_record_claim", "otp_medical_record_claim_mobile"},
	}

	for _, rename := range renames {
		oldExists, err := tableExists(db, schema, rename.oldName)
		if err != nil {
			return err
		}
		if !oldExists {
			continue
		}

		newExists, err := tableExists(db, schema, rename.newName)
		if err != nil {
			return err
		}
		if newExists {
			continue
		}

		if _, err = db.Exec(fmt.Sprintf(
			"RENAME TABLE `%s` TO `%s`",
			rename.oldName,
			rename.newName,
		)); err != nil {
			return fmt.Errorf("rename table %s to %s: %w", rename.oldName, rename.newName, err)
		}
	}

	return nil
}

func tableExists(db *sql.DB, schema string, table string) (bool, error) {
	var count int
	if err := db.QueryRow(`
		SELECT COUNT(*)
		FROM information_schema.TABLES
		WHERE TABLE_SCHEMA = ?
		AND TABLE_NAME = ?
	`, schema, table).Scan(&count); err != nil {
		return false, err
	}

	return count > 0, nil
}

func ensureColumn(db *sql.DB, schema string, table string, column string, ddl string) error {
	var count int
	if err := db.QueryRow(`
		SELECT COUNT(*)
		FROM information_schema.COLUMNS
		WHERE TABLE_SCHEMA = ?
		AND TABLE_NAME = ?
		AND COLUMN_NAME = ?
	`, schema, table, column).Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	_, err := db.Exec(ddl)
	return err
}

func ensureIndex(db *sql.DB, schema string, table string, index string, ddl string) error {
	var count int
	if err := db.QueryRow(`
		SELECT COUNT(*)
		FROM information_schema.STATISTICS
		WHERE TABLE_SCHEMA = ?
		AND TABLE_NAME = ?
		AND INDEX_NAME = ?
	`, schema, table, index).Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	_, err := db.Exec(ddl)
	return err
}

func dropIndexIfExists(db *sql.DB, schema string, table string, index string) error {
	var count int
	if err := db.QueryRow(`
		SELECT COUNT(*)
		FROM information_schema.STATISTICS
		WHERE TABLE_SCHEMA = ?
		AND TABLE_NAME = ?
		AND INDEX_NAME = ?
	`, schema, table, index).Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		return nil
	}

	_, err := db.Exec(fmt.Sprintf("ALTER TABLE `%s` DROP INDEX `%s`", table, index))
	return err
}
