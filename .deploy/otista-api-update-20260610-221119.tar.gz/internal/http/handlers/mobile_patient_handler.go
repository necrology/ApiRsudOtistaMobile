package handlers

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"

	"apirusdotistamobile/internal/http/response"
	"apirusdotistamobile/internal/repository"

	"github.com/gofiber/fiber/v2"
)

type MobilePatientHandler struct {
	repository *repository.MobilePatientRepository
}

func NewMobilePatientHandler(repository *repository.MobilePatientRepository) *MobilePatientHandler {
	return &MobilePatientHandler{repository: repository}
}

func (h *MobilePatientHandler) Profile(c *fiber.Ctx) error {
	email, noRM, err := mobilePatientIdentity(c)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 8*time.Second)
	defer cancel()

	profile, err := h.repository.Profile(ctx, email, noRM)
	if err != nil {
		return h.handlePatientError(c, err)
	}

	return response.OK(c, profile)
}

func (h *MobilePatientHandler) Visits(c *fiber.Ctx) error {
	email, noRM, err := mobilePatientIdentity(c)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 10*time.Second)
	defer cancel()

	visits, err := h.repository.Visits(ctx, email, noRM, c.QueryInt("limit", 20))
	if err != nil {
		return h.handlePatientError(c, err)
	}

	return response.OK(c, visits)
}

func (h *MobilePatientHandler) MedicalSummaries(c *fiber.Ctx) error {
	email, noRM, err := mobilePatientIdentity(c)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 10*time.Second)
	defer cancel()

	summaries, err := h.repository.MedicalSummaries(ctx, email, noRM, c.QueryInt("limit", 20))
	if err != nil {
		return h.handlePatientError(c, err)
	}

	return response.OK(c, summaries)
}

func (h *MobilePatientHandler) LaboratoryResults(c *fiber.Ctx) error {
	email, noRM, err := mobilePatientIdentity(c)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 12*time.Second)
	defer cancel()

	results, err := h.repository.LaboratoryResults(ctx, email, noRM, c.QueryInt("limit", 20))
	if err != nil {
		return h.handlePatientError(c, err)
	}

	return response.OK(c, results)
}

func (h *MobilePatientHandler) RadiologyResults(c *fiber.Ctx) error {
	email, noRM, err := mobilePatientIdentity(c)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 12*time.Second)
	defer cancel()

	results, err := h.repository.RadiologyResults(ctx, email, noRM, c.QueryInt("limit", 20))
	if err != nil {
		return h.handlePatientError(c, err)
	}

	return response.OK(c, results)
}

func (h *MobilePatientHandler) Prescriptions(c *fiber.Ctx) error {
	email, noRM, err := mobilePatientIdentity(c)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 12*time.Second)
	defer cancel()

	results, err := h.repository.Prescriptions(ctx, email, noRM, c.QueryInt("limit", 20))
	if err != nil {
		return h.handlePatientError(c, err)
	}

	return response.OK(c, results)
}

func (h *MobilePatientHandler) handlePatientError(c *fiber.Ctx, err error) error {
	if errors.Is(err, sql.ErrNoRows) {
		return response.Error(c, fiber.StatusNotFound, "No. RM belum terhubung ke akun mobile")
	}

	if errors.Is(err, context.DeadlineExceeded) {
		return response.Error(c, fiber.StatusGatewayTimeout, "permintaan data pasien terlalu lama")
	}

	return response.Error(c, fiber.StatusInternalServerError, "gagal mengambil data pasien")
}

func mobilePatientIdentity(c *fiber.Ctx) (string, string, error) {
	email := strings.TrimSpace(c.Query("email"))
	noRM := strings.TrimSpace(c.Query("no_rm"))
	if noRM == "" {
		noRM = strings.TrimSpace(c.Query("noRm"))
	}

	if email == "" || noRM == "" {
		return "", "", errors.New("email dan no_rm wajib diisi")
	}

	return email, noRM, nil
}
