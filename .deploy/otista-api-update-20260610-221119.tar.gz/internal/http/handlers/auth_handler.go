package handlers

import (
	"apirusdotistamobile/internal/auth"
	"apirusdotistamobile/internal/model"

	"github.com/gofiber/fiber/v2"
)

type AuthHandler struct {
	Service *auth.Service
}

func NewAuthHandler(service *auth.Service) *AuthHandler {
	return &AuthHandler{
		Service: service,
	}
}

func (h *AuthHandler) Register(c *fiber.Ctx) error {

	var req model.RegisterRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	err := h.Service.RegisterUser(req)

	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "otp terkirim ke email, silahkan cek email untuk verifikasi",
	})
}

func (h *AuthHandler) VerifyOTPNewUser(c *fiber.Ctx) error {

	var req model.VerifyOTPNewUser

	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	err := h.Service.VerifyOTPNewUser(req)

	if err != nil {
		return c.Status(401).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "Register otp verified",
	})
}

func (h *AuthHandler) SetPassword(
	c *fiber.Ctx,
) error {

	var req model.SetPasswordRequest

	if err := c.BodyParser(&req); err != nil {

		return c.Status(400).JSON(
			fiber.Map{
				"message": "invalid request body",
			},
		)
	}

	user, err := h.Service.SetPassword(req)

	if err != nil {

		return c.Status(400).JSON(
			fiber.Map{
				"message": err.Error(),
			},
		)
	}

	return c.JSON(fiber.Map{
		"message": "register success",
		"data":    userIdentityResponse(user),
	})
}

func (h *AuthHandler) Login(c *fiber.Ctx) error {

	var req model.LoginRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	err := h.Service.Login(req)

	if err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "login success",
	})

}
func (h *AuthHandler) VerifyEmail(c *fiber.Ctx) error {

	token := c.Query("token")

	err := h.Service.VerifyEmail(token)

	if err != nil {
		return c.Status(400).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "email verified",
	})
}

func (h *AuthHandler) VerifyOTPLogin(c *fiber.Ctx) error {

	var req model.VerifyOTPRequestLogin

	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	user, err := h.Service.VerifyOTPLogin(req)

	if err != nil {
		return c.Status(401).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "otp verified",
		"data":    userIdentityResponse(user),
	})
}

func (h *AuthHandler) ForgotPassword(c *fiber.Ctx) error {
	var req model.ForgotPasswordRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	if err := h.Service.ForgotPassword(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "otp reset password terkirim ke email",
	})
}

func (h *AuthHandler) ResetPassword(c *fiber.Ctx) error {
	var req model.ResetPasswordRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	if err := h.Service.ResetPassword(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "password berhasil diperbarui",
	})
}

func (h *AuthHandler) RequestMedicalRecordClaim(c *fiber.Ctx) error {
	var req model.RequestMedicalRecordClaim

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	if err := h.Service.RequestMedicalRecordClaim(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "otp verifikasi no rm terkirim ke email",
	})
}

func (h *AuthHandler) ConfirmMedicalRecordClaim(c *fiber.Ctx) error {
	var req model.ConfirmMedicalRecordClaim

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "invalid request body",
		})
	}

	user, err := h.Service.ConfirmMedicalRecordClaim(req)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"message": "no rm berhasil terhubung",
		"data":    userIdentityResponse(user),
	})
}

func userIdentityResponse(user *model.User) fiber.Map {
	return fiber.Map{
		"id":                  user.Email,
		"patientId":           user.PatientID,
		"fullName":            user.FullName,
		"email":               user.Email,
		"phoneNumber":         user.Phone,
		"medicalRecordNumber": user.NoRM,
		"familyMembers":       []string{},
	}
}
