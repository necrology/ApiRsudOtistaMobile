package routes

import (
	"apirusdotistamobile/internal/http/handlers"

	"github.com/gofiber/fiber/v2"
)

func BookingRoutes(v1 fiber.Router, bookingHandler *handlers.BookingHandler) {
	booking := v1.Group("/mobile/booking")
	booking.Get("/general", bookingHandler.ListGeneralBookings)
	booking.Get("/general/mine", bookingHandler.ListMyGeneralBookings)
	booking.Post("/general", bookingHandler.CreateGeneralBooking)
}
