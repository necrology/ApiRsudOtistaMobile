-- File ini untuk menyimpan query perubahan pada tabel / buat tabel baru

-- Query table test
CREATE TABLE table_test (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(50) NOT NULL,
    usia INT,
    tanggal_daftar DATE
);

-- Query alter table test
ALTER TABLE test ADD email VARCHAR(100) AFTER nama;



--tambah table user login
CREATE TABLE user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    username VARCHAR(100) NOT NULL,

    email VARCHAR(100) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL,

    is_deleted BOOLEAN DEFAULT FALSE,

    deleted_at TIMESTAMP NULL DEFAULT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP
);

--tambah table otp_user_login
CREATE TABLE otp_user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT NOT NULL,

    otp_code VARCHAR(10) NOT NULL,

    expired_at TIMESTAMP NOT NULL,

    is_used BOOLEAN DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
    REFERENCES user(id)
    ON DELETE CASCADE
);

--tambah table otp_verif_email
CREATE TABLE otp_verif_email (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    username VARCHAR(100) NOT NULL,

    email VARCHAR(100) NOT NULL,

    otp_code VARCHAR(10) NOT NULL,

    expired_at TIMESTAMP NOT NULL,

    is_used BOOLEAN DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2026-05-24: skema auth mobile
-- Login mobile mendukung identifier email atau nomor rekam medis (no_rm).
-- Register mobile bisa untuk pasien yang sudah punya no_rm maupun user baru tanpa no_rm.
ALTER TABLE user
    ADD COLUMN no_rm VARCHAR(20) NULL AFTER email,
    ADD COLUMN phone VARCHAR(30) NULL AFTER no_rm,
    ADD COLUMN full_name VARCHAR(150) NULL AFTER phone,
    ADD UNIQUE KEY uk_user_no_rm (no_rm);

ALTER TABLE otp_verif_email
    ADD COLUMN no_rm VARCHAR(20) NULL AFTER email,
    ADD COLUMN phone VARCHAR(30) NULL AFTER no_rm,
    ADD COLUMN full_name VARCHAR(150) NULL AFTER phone;

CREATE TABLE otp_password_reset (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    otp_code VARCHAR(10) NOT NULL,
    expired_at TIMESTAMP NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)
    REFERENCES user(id)
    ON DELETE CASCADE
);

-- 2026-05-29: klaim/update No. RM dipisah dari register akun
-- Register hanya membuat akun dan verifikasi email. No. RM baru terhubung
-- setelah user login, mencocokkan no_rm + nik + tanggal_lahir, lalu OTP email.
ALTER TABLE user
    ADD COLUMN patient_id BIGINT UNSIGNED NULL AFTER no_rm,
    ADD COLUMN medical_record_verified_at TIMESTAMP NULL DEFAULT NULL AFTER verified_at,
    ADD UNIQUE KEY uk_user_patient_id (patient_id);

CREATE TABLE otp_medical_record_claim (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    patient_id BIGINT UNSIGNED NOT NULL,
    no_rm VARCHAR(20) NOT NULL,
    patient_name VARCHAR(150) NULL,
    otp_code VARCHAR(10) NOT NULL,
    expired_at TIMESTAMP NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)
    REFERENCES user(id)
    ON DELETE CASCADE,
    KEY idx_otp_medical_record_claim_user (user_id),
    KEY idx_otp_medical_record_claim_no_rm (no_rm)
);

-- 2026-05-29: rename tabel khusus aplikasi mobile agar mudah dibedakan
-- Jalankan hanya jika tabel lama masih ada dan tabel target belum ada.
RENAME TABLE
    `user` TO `user_mobile`,
    `otp_user` TO `otp_user_mobile`,
    `otp_verif_email` TO `otp_verif_email_mobile`,
    `otp_password_reset` TO `otp_password_reset_mobile`,
    `otp_medical_record_claim` TO `otp_medical_record_claim_mobile`;

-- Nama tabel khusus mobile setelah perubahan:
-- user_mobile
-- otp_user_mobile
-- otp_verif_email_mobile
-- otp_password_reset_mobile
-- otp_medical_record_claim_mobile

-- 2026-06-01: pengamanan auth mobile dan klaim rekam medis
-- Login mobile mendukung email atau No. RM yang sudah terhubung ke akun mobile.
-- Jika No. RM belum terhubung, user diminta login dengan email lalu hubungkan No. RM.
-- Reset password mobile tetap melalui email akun.
-- No. RM tidak boleh unique di akun mobile karena di tabel pasiens SIMRS no_rm bisa duplikat.
-- Relasi permanen akun mobile ke pasien tetap melalui user_mobile.patient_id -> pasiens.id.
ALTER TABLE `user_mobile`
    DROP INDEX `uk_user_no_rm`;

ALTER TABLE `user_mobile`
    ADD KEY `idx_user_mobile_no_rm` (`no_rm`);

ALTER TABLE `otp_user_mobile`
    ADD KEY `idx_otp_user_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`);

ALTER TABLE `otp_verif_email_mobile`
    ADD KEY `idx_otp_verif_email_mobile_email_used_expired` (`email`, `is_used`, `expired_at`);

ALTER TABLE `otp_password_reset_mobile`
    ADD KEY `idx_otp_password_reset_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`);

ALTER TABLE `otp_medical_record_claim_mobile`
    ADD KEY `idx_otp_medical_record_claim_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`);

-- 2026-06-08: booking umum dan antrian poli mobile
-- Skema existing yang dipakai:
-- registrasis.pasien_id -> pasiens.id
-- registrasis.poli_id -> polis.id
-- registrasis.dokter_id -> pegawais.id (disimpan sebagai varchar)
-- registrasis.antrian_poli_id -> antrian_poli.id
-- antrian_poli.registrasi_id -> registrasis.id
-- nomor antrian umum disimpan di registrasis.nomorantrian dan antrian_poli.nomor
-- nomor antrian JKN disimpan di registrasis.nomorantrian_jkn
-- catatan implementasi: booking umum harus dibuat transaksional supaya registrasi dan antrian selalu sinkron
-- endpoint baru:
-- POST /api/v1/mobile/booking/general

-- 2026-06-10: antrian umum mobile, list booking pendaftaran, dan resep pasien
-- Fitur mobile memakai tabel existing `registrasis` + `antrian_poli`, bukan tabel dummy.
-- Alur:
-- 1. Pasien harus sudah punya No. RM yang terhubung ke `user_mobile.patient_id`.
-- 2. POST /api/v1/mobile/booking/general membuat `registrasis` dan `antrian_poli`.
-- 3. GET /api/v1/mobile/booking/general menampilkan list booking umum untuk bagian pendaftaran.
-- 4. GET /api/v1/mobile/booking/general/mine menampilkan booking pasien login.
-- 5. GET /api/v1/mobile/patient/prescriptions menampilkan resep dari `penjualans` + `penjualandetails`.

-- Index pendukung list booking pendaftaran dan pengecekan duplicate booking.
-- Jalankan bila index belum ada.
ALTER TABLE registrasis
    ADD INDEX idx_registrasis_mobile_booking (
        input_from,
        pasien_id,
        poli_id,
        tgl_order,
        deleted_at
    );

ALTER TABLE antrian_poli
    ADD INDEX idx_antrian_poli_mobile_booking (
        poli_id,
        tanggal,
        status,
        panggil,
        nomor
    );

ALTER TABLE penjualans
    ADD INDEX idx_penjualans_mobile_patient (
        registrasi_id,
        deleted_at,
        created_at
    );

ALTER TABLE penjualandetails
    ADD INDEX idx_penjualandetails_mobile_prescription (
        penjualan_id,
        deleted_at
    );

-- Query list booking umum hari ini untuk pendaftaran.
SELECT
    r.id AS registration_id,
    r.reg_id AS registration_code,
    COALESCE(NULLIF(r.nomorantrian, ''), CAST(a.nomor AS CHAR)) AS queue_number,
    CONCAT('U-', LPAD(COALESCE(a.nomor, r.nomorantrian), 3, '0')) AS queue_code,
    DATE_FORMAT(COALESCE(r.tgl_order, a.tanggal, DATE(r.created_at)), '%Y-%m-%d') AS queue_date,
    p.no_rm,
    p.nama AS nama_pasien,
    po.nama AS nama_poli,
    d.nama AS nama_dokter,
    r.status AS registration_status,
    r.status_reg,
    a.status AS queue_status,
    a.panggil,
    a.sudah_dipanggil,
    r.input_from
FROM registrasis r
INNER JOIN pasiens p ON p.id = r.pasien_id
LEFT JOIN antrian_poli a ON a.id = r.antrian_poli_id
LEFT JOIN polis po ON po.id = r.poli_id
LEFT JOIN pegawais d ON d.id = CAST(r.dokter_id AS UNSIGNED)
WHERE r.deleted_at IS NULL
  AND COALESCE(r.input_from, '') = 'mobile'
  AND COALESCE(r.jkn, 'N') <> 'Y'
  AND COALESCE(r.tgl_order, a.tanggal, DATE(r.created_at)) = CURDATE()
ORDER BY COALESCE(r.tgl_order, a.tanggal, DATE(r.created_at)) DESC, r.id DESC;

-- Query antrian Mobile JKN dari registrasis_dummy tetap untuk monitoring BPJS,
-- bukan untuk membuat antrian umum mobile.
SELECT
    id,
    kodebooking,
    nomorkartu,
    no_rm,
    nama,
    tglperiksa,
    kode_poli,
    kode_dokter,
    status,
    jenisrequest
FROM registrasis_dummy
WHERE jenisrequest IN (1, 2)
   OR request LIKE '%mobile_jkn%'
ORDER BY id DESC;

-- Query resep/obat pasien berdasarkan No. RM.
SELECT
    pj.id AS penjualan_id,
    pj.no_resep,
    r.reg_id,
    p.no_rm,
    p.nama AS nama_pasien,
    po.nama AS nama_poli,
    dokter.nama AS nama_dokter,
    pj.created_at AS tanggal_resep,
    pj.done_input AS status_resep,
    pd.id AS detail_id,
    mo.nama AS nama_obat,
    mo.kode AS kode_obat,
    mo.satuan_obat,
    pd.jumlah,
    pd.cara_minum,
    pd.takaran,
    pd.informasi1,
    pd.informasi2,
    pd.catatan,
    pd.etiket,
    pd.obat_racikan,
    pd.is_kronis
FROM penjualans pj
INNER JOIN registrasis r ON r.id = pj.registrasi_id
INNER JOIN pasiens p ON p.id = r.pasien_id
LEFT JOIN polis po ON po.id = r.poli_id
LEFT JOIN pegawais dokter ON dokter.id = pj.dokter_id
LEFT JOIN penjualandetails pd ON pd.penjualan_id = pj.id AND pd.deleted_at IS NULL
LEFT JOIN masterobats mo ON mo.id = pd.masterobat_id
WHERE p.no_rm = 'NO_RM_DI_SINI'
  AND pj.deleted_at IS NULL
ORDER BY pj.created_at DESC, pj.id DESC, pd.id ASC;
