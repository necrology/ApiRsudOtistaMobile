package repository

import (
	"context"
	"database/sql"
	"strings"
)

type MobilePatientRepository struct {
	DB *sql.DB
}

type MobilePatientProfile struct {
	ID          int64  `json:"id"`
	NoRM        string `json:"no_rm"`
	FullName    string `json:"nama"`
	Gender      string `json:"kelamin"`
	BirthPlace  string `json:"tmplahir"`
	BirthDate   string `json:"tgllahir"`
	Address     string `json:"alamat"`
	PhoneNumber string `json:"nohp"`
	BloodType   string `json:"golda"`
}

type MobilePatientVisit struct {
	ID           int64  `json:"id"`
	Registration string `json:"reg_id"`
	QueueNumber  string `json:"nomorantrian"`
	VisitDate    string `json:"tanggal_kunjungan"`
	CreatedAt    string `json:"created_at"`
	FinishedAt   string `json:"tgl_pulang"`
	PatientType  string `json:"jenis_pasien"`
	PaymentType  string `json:"bayar"`
	ServiceType  string `json:"tipe_rawat"`
	Status       string `json:"status"`
	Polyclinic   string `json:"poli"`
	Doctor       string `json:"dokter"`
	QueueGroup   string `json:"kelompok_antrian"`
}

type MobilePatientMedicalSummary struct {
	ID           int64  `json:"id"`
	Registration string `json:"reg_id"`
	VisitDate    string `json:"tanggal_kunjungan"`
	Polyclinic   string `json:"poli"`
	Doctor       string `json:"dokter"`
	Diagnosis    string `json:"diagnosa"`
	Action       string `json:"tindakan"`
	Note         string `json:"keterangan"`
}

type MobilePatientLabResult struct {
	ID                int64                          `json:"id"`
	NoLab             string                         `json:"no_lab"`
	Registration      string                         `json:"reg_id"`
	VisitDate         string                         `json:"tanggal_kunjungan"`
	Polyclinic        string                         `json:"poli"`
	Doctor            string                         `json:"dokter"`
	Responsible       string                         `json:"penanggungjawab"`
	ExamDate          string                         `json:"tgl_pemeriksaan"`
	ReceivedDate      string                         `json:"tgl_bahanditerima"`
	ResultDate        string                         `json:"tgl_hasilselesai"`
	PrintDate         string                         `json:"tgl_cetak"`
	StartTime         string                         `json:"jam"`
	FinishTime        string                         `json:"jamkeluar"`
	Sample            string                         `json:"sample"`
	Message           string                         `json:"pesan"`
	Impression        string                         `json:"kesan"`
	Suggestion        string                         `json:"saran"`
	OrderExaminations string                         `json:"pemeriksaan_order"`
	OrderType         string                         `json:"jenis_order"`
	LabType           string                         `json:"tipe_lab"`
	Diagnosis         string                         `json:"diagnosa"`
	Details           []MobilePatientLabResultDetail `json:"rincian"`
}

type MobilePatientLabResultDetail struct {
	ID            int64  `json:"id"`
	Section       string `json:"section"`
	Category      string `json:"kategori"`
	Examination   string `json:"pemeriksaan"`
	Reference     string `json:"rujukan"`
	ReferenceLow  string `json:"nilai_rujukan_bawah"`
	ReferenceHigh string `json:"nilai_rujukan_atas"`
	Unit          string `json:"satuan"`
	ResultText    string `json:"hasil_text"`
	ResultValue   string `json:"hasil"`
}

type MobilePatientRadiologyResult struct {
	ID              int64  `json:"id"`
	Registration    string `json:"reg_id"`
	VisitDate       string `json:"tanggal_kunjungan"`
	Polyclinic      string `json:"poli"`
	Doctor          string `json:"dokter"`
	DocumentNumber  string `json:"no_dokument"`
	ExamDate        string `json:"tanggal_periksa"`
	ResultDate      string `json:"tanggal_ekspertise"`
	Examination     string `json:"pemeriksaan"`
	OrderType       string `json:"jenis_order"`
	Status          string `json:"status"`
	Source          string `json:"source"`
	ClinicalNote    string `json:"klinis"`
	ResultSummary   string `json:"resume"`
	Expertise       string `json:"ekspertise"`
	OrderCreatedAt  string `json:"order_created_at"`
	ResultCreatedAt string `json:"result_created_at"`
}

type MobilePatientPrescription struct {
	ID           int64                             `json:"id"`
	NoResep      string                            `json:"no_resep"`
	Registration string                            `json:"reg_id"`
	VisitDate    string                            `json:"tanggal_kunjungan"`
	Polyclinic   string                            `json:"poli"`
	Doctor       string                            `json:"dokter"`
	CreatedAt    string                            `json:"created_at"`
	Status       string                            `json:"status"`
	Note         string                            `json:"catatan"`
	Details      []MobilePatientPrescriptionDetail `json:"rincian"`
}

type MobilePatientPrescriptionDetail struct {
	ID          int64  `json:"id"`
	DrugName    string `json:"nama_obat"`
	DrugCode    string `json:"kode_obat"`
	Unit        string `json:"satuan"`
	Quantity    int64  `json:"jumlah"`
	HowToUse    string `json:"cara_minum"`
	Dose        string `json:"takaran"`
	InfoPrimary string `json:"informasi1"`
	InfoExtra   string `json:"informasi2"`
	Note        string `json:"catatan"`
	Label       string `json:"etiket"`
	Compound    string `json:"obat_racikan"`
	Chronic     string `json:"is_kronis"`
}

func NewMobilePatientRepository(db *sql.DB) *MobilePatientRepository {
	return &MobilePatientRepository{DB: db}
}

func (r *MobilePatientRepository) Profile(ctx context.Context, email string, noRM string) (*MobilePatientProfile, error) {
	email = strings.TrimSpace(email)
	noRM = strings.TrimSpace(noRM)

	query := `
	SELECT
		p.id,
		COALESCE(p.no_rm, ''),
		COALESCE(p.nama, ''),
		COALESCE(p.kelamin, ''),
		COALESCE(p.tmplahir, ''),
		COALESCE(p.tgllahir, ''),
		COALESCE(p.alamat, ''),
		COALESCE(p.nohp, COALESCE(p.notlp, '')),
		COALESCE(p.golda, '')
	FROM user_mobile u
	INNER JOIN pasiens p ON p.id = u.patient_id
	WHERE u.email = ?
	AND u.no_rm = ?
	AND COALESCE(u.patient_id, 0) <> 0
	AND COALESCE(u.is_deleted, false) = false
	LIMIT 1
	`

	var profile MobilePatientProfile
	if err := r.DB.QueryRowContext(ctx, query, email, noRM).Scan(
		&profile.ID,
		&profile.NoRM,
		&profile.FullName,
		&profile.Gender,
		&profile.BirthPlace,
		&profile.BirthDate,
		&profile.Address,
		&profile.PhoneNumber,
		&profile.BloodType,
	); err != nil {
		return nil, err
	}

	profile.Gender = normalizeGender(profile.Gender)

	return &profile, nil
}

func (r *MobilePatientRepository) Visits(ctx context.Context, email string, noRM string, limit int) ([]MobilePatientVisit, error) {
	profile, err := r.Profile(ctx, email, noRM)
	if err != nil {
		return nil, err
	}

	limit = normalizeMobileLimit(limit)

	query := `
	SELECT
		r.id,
		COALESCE(r.reg_id, ''),
		COALESCE(NULLIF(r.nomorantrian, ''), COALESCE(CAST(a.nomor AS CHAR), '')),
		COALESCE(DATE_FORMAT(r.tgl_order, '%Y-%m-%d'), DATE_FORMAT(r.created_at, '%Y-%m-%d'), ''),
		COALESCE(DATE_FORMAT(r.created_at, '%Y-%m-%d %H:%i'), ''),
		COALESCE(DATE_FORMAT(r.tgl_pulang, '%Y-%m-%d %H:%i'), ''),
		COALESCE(r.jenis_pasien, ''),
		COALESCE(NULLIF(cb.carabayar, ''), NULLIF(r.bayar, ''), ''),
		COALESCE(r.tipe_rawat, ''),
		COALESCE(r.status, ''),
		COALESCE(po.nama, ''),
		COALESCE(d.nama, ''),
		COALESCE(a.kelompok, '')
	FROM registrasis r
	LEFT JOIN polis po ON po.id = r.poli_id
	LEFT JOIN pegawais d ON d.id = CAST(r.dokter_id AS UNSIGNED)
	LEFT JOIN antrian_poli a ON a.id = r.antrian_poli_id
	LEFT JOIN carabayars cb ON cb.id = CAST(NULLIF(r.bayar, '') AS UNSIGNED)
	WHERE r.pasien_id = ?
	ORDER BY COALESCE(r.tgl_order, DATE(r.created_at)) DESC, r.id DESC
	LIMIT ?
	`

	rows, err := r.DB.QueryContext(ctx, query, profile.ID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	visits := make([]MobilePatientVisit, 0)
	for rows.Next() {
		var visit MobilePatientVisit
		if err = rows.Scan(
			&visit.ID,
			&visit.Registration,
			&visit.QueueNumber,
			&visit.VisitDate,
			&visit.CreatedAt,
			&visit.FinishedAt,
			&visit.PatientType,
			&visit.PaymentType,
			&visit.ServiceType,
			&visit.Status,
			&visit.Polyclinic,
			&visit.Doctor,
			&visit.QueueGroup,
		); err != nil {
			return nil, err
		}
		visit.PatientType = normalizePatientType(visit.PatientType)
		visit.PaymentType = normalizePaymentType(visit.PaymentType)
		visits = append(visits, visit)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return visits, nil
}

func (r *MobilePatientRepository) MedicalSummaries(ctx context.Context, email string, noRM string, limit int) ([]MobilePatientMedicalSummary, error) {
	profile, err := r.Profile(ctx, email, noRM)
	if err != nil {
		return nil, err
	}

	limit = normalizeMobileLimit(limit)

	query := `
	SELECT
		COALESCE(MAX(rp.id), r.id),
		COALESCE(r.reg_id, ''),
		COALESCE(DATE_FORMAT(r.tgl_order, '%Y-%m-%d'), DATE_FORMAT(r.created_at, '%Y-%m-%d'), ''),
		COALESCE(po.nama, ''),
		COALESCE(d.nama, ''),
		COALESCE(
			NULLIF(GROUP_CONCAT(DISTINCT NULLIF(rp.diagnosa, '') SEPARATOR '\n'), ''),
			NULLIF(GROUP_CONCAT(DISTINCT NULLIF(CONCAT_WS(' - ', NULLIF(j10.icd10, ''), NULLIF(j10.diagnosis, '')), '') SEPARATOR '\n'), ''),
			NULLIF(GROUP_CONCAT(DISTINCT NULLIF(CONCAT_WS(' - ', NULLIF(p10.icd10, ''), NULLIF(p10.diagnosis, '')), '') SEPARATOR '\n'), ''),
			NULLIF(r.diagnosa_awal, ''),
			NULLIF(r.diagnosa_inap, ''),
			NULLIF(r.icd, ''),
			''
		) AS diagnosis_text,
		COALESCE(
			NULLIF(GROUP_CONCAT(DISTINCT NULLIF(rp.tindakan, '') SEPARATOR '\n'), ''),
			NULLIF(GROUP_CONCAT(DISTINCT NULLIF(CONCAT_WS(' - ', NULLIF(j9.icd9, ''), NULLIF(j9.diagnosis, '')), '') SEPARATOR '\n'), ''),
			NULLIF(GROUP_CONCAT(DISTINCT NULLIF(CONCAT_WS(' - ', NULLIF(p9.icd9, ''), NULLIF(p9.diagnosis, '')), '') SEPARATOR '\n'), ''),
			''
		) AS action_text,
		COALESCE(NULLIF(GROUP_CONCAT(DISTINCT NULLIF(rp.keterangan, '') SEPARATOR '\n'), ''), '')
	FROM registrasis r
	LEFT JOIN resume_pasiens rp ON rp.registrasi_id = r.id
	LEFT JOIN jkn_icd10s j10 ON j10.registrasi_id = r.id
	LEFT JOIN jkn_icd9s j9 ON j9.registrasi_id = r.id
	LEFT JOIN perawatan_icd10s p10 ON p10.registrasi_id = r.id
	LEFT JOIN perawatan_icd9s p9 ON p9.registrasi_id = r.id
	LEFT JOIN polis po ON po.id = r.poli_id
	LEFT JOIN pegawais d ON d.id = CAST(r.dokter_id AS UNSIGNED)
	WHERE r.pasien_id = ?
	GROUP BY
		r.id,
		r.reg_id,
		r.tgl_order,
		r.created_at,
		po.nama,
		d.nama,
		r.diagnosa_awal,
		r.diagnosa_inap,
		r.icd
	HAVING diagnosis_text <> '' OR action_text <> ''
	ORDER BY COALESCE(r.tgl_order, DATE(r.created_at)) DESC, COALESCE(MAX(rp.id), r.id) DESC
	LIMIT ?
	`

	rows, err := r.DB.QueryContext(ctx, query, profile.ID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	summaries := make([]MobilePatientMedicalSummary, 0)
	for rows.Next() {
		var summary MobilePatientMedicalSummary
		if err = rows.Scan(
			&summary.ID,
			&summary.Registration,
			&summary.VisitDate,
			&summary.Polyclinic,
			&summary.Doctor,
			&summary.Diagnosis,
			&summary.Action,
			&summary.Note,
		); err != nil {
			return nil, err
		}
		summaries = append(summaries, summary)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return summaries, nil
}

func (r *MobilePatientRepository) LaboratoryResults(ctx context.Context, email string, noRM string, limit int) ([]MobilePatientLabResult, error) {
	profile, err := r.Profile(ctx, email, noRM)
	if err != nil {
		return nil, err
	}

	limit = normalizeMobileLimit(limit)

	query := `
	SELECT
		hl.id,
		COALESCE(hl.no_lab, ''),
		COALESCE(r.reg_id, ''),
		COALESCE(DATE_FORMAT(r.tgl_order, '%Y-%m-%d'), DATE_FORMAT(r.created_at, '%Y-%m-%d'), ''),
		COALESCE(po.nama, ''),
		COALESCE(d.nama, rd.nama, ''),
		COALESCE(hl.penanggungjawab, ''),
		COALESCE(DATE_FORMAT(hl.tgl_pemeriksaan, '%Y-%m-%d'), ''),
		COALESCE(DATE_FORMAT(hl.tgl_bahanditerima, '%Y-%m-%d'), ''),
		COALESCE(DATE_FORMAT(hl.tgl_hasilselesai, '%Y-%m-%d'), ''),
		COALESCE(DATE_FORMAT(hl.tgl_cetak, '%Y-%m-%d'), ''),
		COALESCE(hl.jam, ''),
		COALESCE(hl.jamkeluar, ''),
		COALESCE(hl.sample, ''),
		COALESCE(hl.pesan, ''),
		COALESCE(hl.kesan, ''),
		COALESCE(hl.saran, ''),
		COALESCE(ol.pemeriksaan, ''),
		COALESCE(ol.jenis, ''),
		COALESCE(ol.tipe_lab, ''),
		COALESCE(ol.diagnosa, '')
	FROM hasillabs hl
	INNER JOIN registrasis r ON r.id = hl.registrasi_id
	LEFT JOIN order_lab ol ON ol.id = hl.order_lab_id
	LEFT JOIN polis po ON po.id = r.poli_id
	LEFT JOIN pegawais d ON d.id = hl.dokter_id
	LEFT JOIN pegawais rd ON rd.id = CAST(r.dokter_id AS UNSIGNED)
	WHERE r.pasien_id = ?
	AND hl.deleted_at IS NULL
	ORDER BY COALESCE(hl.tgl_hasilselesai, hl.tgl_pemeriksaan, hl.created_at) DESC, hl.id DESC
	LIMIT ?
	`

	rows, err := r.DB.QueryContext(ctx, query, profile.ID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	results := make([]MobilePatientLabResult, 0)
	resultIndexByID := make(map[int64]int)
	labIDs := make([]int64, 0)

	for rows.Next() {
		var result MobilePatientLabResult
		if err = rows.Scan(
			&result.ID,
			&result.NoLab,
			&result.Registration,
			&result.VisitDate,
			&result.Polyclinic,
			&result.Doctor,
			&result.Responsible,
			&result.ExamDate,
			&result.ReceivedDate,
			&result.ResultDate,
			&result.PrintDate,
			&result.StartTime,
			&result.FinishTime,
			&result.Sample,
			&result.Message,
			&result.Impression,
			&result.Suggestion,
			&result.OrderExaminations,
			&result.OrderType,
			&result.LabType,
			&result.Diagnosis,
		); err != nil {
			return nil, err
		}
		result.Details = []MobilePatientLabResultDetail{}
		resultIndexByID[result.ID] = len(results)
		labIDs = append(labIDs, result.ID)
		results = append(results, result)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	if len(labIDs) == 0 {
		return results, nil
	}

	details, err := r.labResultDetails(ctx, labIDs)
	if err != nil {
		return nil, err
	}

	for labID, detailItems := range details {
		index, ok := resultIndexByID[labID]
		if !ok {
			continue
		}
		results[index].Details = detailItems
	}

	return results, nil
}

func (r *MobilePatientRepository) labResultDetails(ctx context.Context, labIDs []int64) (map[int64][]MobilePatientLabResultDetail, error) {
	placeholders := sqlPlaceholders(len(labIDs))
	args := make([]any, 0, len(labIDs))
	for _, labID := range labIDs {
		args = append(args, labID)
	}

	query := `
	SELECT
		rh.hasillab_id,
		rh.id,
		COALESCE(ls.nama, ''),
		COALESCE(lk.nama, ''),
		COALESCE(lb.nama, ''),
		COALESCE(lb.rujukan, ''),
		COALESCE(lb.nilairujukanbawah, ''),
		COALESCE(lb.nilairujukanatas, ''),
		COALESCE(lb.satuan, ''),
		COALESCE(rh.hasiltext, ''),
		COALESCE(rh.hasil, '')
	FROM rincian_hasillabs rh
	LEFT JOIN labsections ls ON ls.id = rh.labsection_id
	LEFT JOIN labkategoris lk ON lk.id = rh.labkategori_id
	LEFT JOIN laboratoria lb ON lb.id = rh.laboratoria_id
	WHERE rh.hasillab_id IN (` + placeholders + `)
	ORDER BY rh.hasillab_id DESC, ls.nama ASC, lk.nama ASC, lb.nama ASC, rh.id ASC
	`

	rows, err := r.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	details := make(map[int64][]MobilePatientLabResultDetail)
	for rows.Next() {
		var (
			labID  int64
			detail MobilePatientLabResultDetail
		)
		if err = rows.Scan(
			&labID,
			&detail.ID,
			&detail.Section,
			&detail.Category,
			&detail.Examination,
			&detail.Reference,
			&detail.ReferenceLow,
			&detail.ReferenceHigh,
			&detail.Unit,
			&detail.ResultText,
			&detail.ResultValue,
		); err != nil {
			return nil, err
		}
		details[labID] = append(details[labID], detail)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return details, nil
}

func (r *MobilePatientRepository) RadiologyResults(ctx context.Context, email string, noRM string, limit int) ([]MobilePatientRadiologyResult, error) {
	profile, err := r.Profile(ctx, email, noRM)
	if err != nil {
		return nil, err
	}

	limit = normalizeMobileLimit(limit)

	query := `
	SELECT
		COALESCE(MAX(re.id), MAX(hr.id), MAX(ord.id), r.id) AS id,
		COALESCE(r.reg_id, ''),
		COALESCE(DATE_FORMAT(r.tgl_order, '%Y-%m-%d'), DATE_FORMAT(r.created_at, '%Y-%m-%d'), ''),
		COALESCE(po.nama, ''),
		COALESCE(MAX(dokter_ahli.nama), MAX(dokter_pengirim.nama), MAX(dokter_reg.nama), MAX(hr.dokter), ''),
		COALESCE(MAX(re.no_dokument), ''),
		COALESCE(MAX(re.tglPeriksa), ''),
		COALESCE(DATE_FORMAT(MAX(re.tanggal_eksp), '%Y-%m-%d'), ''),
		COALESCE(GROUP_CONCAT(DISTINCT ord.pemeriksaan SEPARATOR ', '), GROUP_CONCAT(DISTINCT hr.pemeriksaan SEPARATOR ', '), ''),
		COALESCE(GROUP_CONCAT(DISTINCT ord.jenis SEPARATOR ', '), ''),
		COALESCE(MAX(ord.status), ''),
		COALESCE(MAX(ord.source), ''),
		COALESCE(GROUP_CONCAT(DISTINCT re.klinis SEPARATOR '\n'), ''),
		COALESCE(GROUP_CONCAT(DISTINCT dr.resum SEPARATOR '\n'), ''),
		COALESCE(GROUP_CONCAT(DISTINCT re.ekspertise SEPARATOR '\n'), ''),
		COALESCE(DATE_FORMAT(MAX(ord.created_at), '%Y-%m-%d %H:%i'), ''),
		COALESCE(DATE_FORMAT(MAX(hr.created_at), '%Y-%m-%d %H:%i'), '')
	FROM registrasis r
	LEFT JOIN polis po ON po.id = r.poli_id
	LEFT JOIN pegawais dokter_reg ON dokter_reg.id = CAST(r.dokter_id AS UNSIGNED)
	LEFT JOIN order_radiologi ord ON ord.registrasi_id = r.id
	LEFT JOIN hasilradiologis hr ON hr.registrasi_id = r.id
	LEFT JOIN detailradiologis dr ON dr.hasilradiologi_id = hr.id
	LEFT JOIN radiologi_ekspertises re ON re.registrasi_id = r.id
		AND (re.pasien_id = ? OR re.pasien_id IS NULL OR re.pasien_id = 0)
	LEFT JOIN pegawais dokter_ahli ON dokter_ahli.id = re.dokter_id
	LEFT JOIN pegawais dokter_pengirim ON dokter_pengirim.id = re.dokter_pengirim
	WHERE r.pasien_id = ?
	AND (ord.id IS NOT NULL OR hr.id IS NOT NULL OR re.id IS NOT NULL)
	GROUP BY r.id, r.reg_id, r.tgl_order, r.created_at, po.nama
	ORDER BY COALESCE(MAX(re.tanggal_eksp), MAX(ord.created_at), MAX(hr.created_at), r.created_at) DESC, r.id DESC
	LIMIT ?
	`

	rows, err := r.DB.QueryContext(ctx, query, profile.ID, profile.ID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	results := make([]MobilePatientRadiologyResult, 0)
	for rows.Next() {
		var result MobilePatientRadiologyResult
		if err = rows.Scan(
			&result.ID,
			&result.Registration,
			&result.VisitDate,
			&result.Polyclinic,
			&result.Doctor,
			&result.DocumentNumber,
			&result.ExamDate,
			&result.ResultDate,
			&result.Examination,
			&result.OrderType,
			&result.Status,
			&result.Source,
			&result.ClinicalNote,
			&result.ResultSummary,
			&result.Expertise,
			&result.OrderCreatedAt,
			&result.ResultCreatedAt,
		); err != nil {
			return nil, err
		}
		results = append(results, result)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return results, nil
}

func (r *MobilePatientRepository) Prescriptions(ctx context.Context, email string, noRM string, limit int) ([]MobilePatientPrescription, error) {
	profile, err := r.Profile(ctx, email, noRM)
	if err != nil {
		return nil, err
	}

	limit = normalizeMobileLimit(limit)

	query := `
	SELECT
		pj.id,
		COALESCE(pj.no_resep, ''),
		COALESCE(r.reg_id, ''),
		COALESCE(DATE_FORMAT(r.tgl_order, '%Y-%m-%d'), DATE_FORMAT(r.created_at, '%Y-%m-%d'), ''),
		COALESCE(po.nama, ''),
		COALESCE(d.nama, rd.nama, ''),
		COALESCE(DATE_FORMAT(pj.created_at, '%Y-%m-%d %H:%i'), ''),
		COALESCE(pj.done_input, ''),
		COALESCE(pj.catatan, '')
	FROM penjualans pj
	INNER JOIN registrasis r ON r.id = pj.registrasi_id
	LEFT JOIN polis po ON po.id = r.poli_id
	LEFT JOIN pegawais d ON d.id = pj.dokter_id
	LEFT JOIN pegawais rd ON rd.id = CAST(r.dokter_id AS UNSIGNED)
	WHERE r.pasien_id = ?
	AND pj.deleted_at IS NULL
	ORDER BY pj.created_at DESC, pj.id DESC
	LIMIT ?
	`

	rows, err := r.DB.QueryContext(ctx, query, profile.ID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	results := make([]MobilePatientPrescription, 0)
	resultIndexByID := make(map[int64]int)
	prescriptionIDs := make([]int64, 0)

	for rows.Next() {
		var prescription MobilePatientPrescription
		if err = rows.Scan(
			&prescription.ID,
			&prescription.NoResep,
			&prescription.Registration,
			&prescription.VisitDate,
			&prescription.Polyclinic,
			&prescription.Doctor,
			&prescription.CreatedAt,
			&prescription.Status,
			&prescription.Note,
		); err != nil {
			return nil, err
		}
		prescription.Details = []MobilePatientPrescriptionDetail{}
		resultIndexByID[prescription.ID] = len(results)
		prescriptionIDs = append(prescriptionIDs, prescription.ID)
		results = append(results, prescription)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	if len(prescriptionIDs) == 0 {
		return results, nil
	}

	details, err := r.prescriptionDetails(ctx, prescriptionIDs)
	if err != nil {
		return nil, err
	}

	for prescriptionID, detailItems := range details {
		index, ok := resultIndexByID[prescriptionID]
		if !ok {
			continue
		}
		results[index].Details = detailItems
	}

	return results, nil
}

func (r *MobilePatientRepository) prescriptionDetails(ctx context.Context, prescriptionIDs []int64) (map[int64][]MobilePatientPrescriptionDetail, error) {
	placeholders := sqlPlaceholders(len(prescriptionIDs))
	args := make([]any, 0, len(prescriptionIDs))
	for _, prescriptionID := range prescriptionIDs {
		args = append(args, prescriptionID)
	}

	query := `
	SELECT
		pd.penjualan_id,
		pd.id,
		COALESCE(mo.nama, ''),
		COALESCE(mo.kode, ''),
		COALESCE(mo.satuan_obat, ''),
		COALESCE(pd.jumlah, 0),
		COALESCE(pd.cara_minum, ''),
		COALESCE(pd.takaran, ''),
		COALESCE(pd.informasi1, ''),
		COALESCE(pd.informasi2, ''),
		COALESCE(pd.catatan, ''),
		COALESCE(pd.etiket, ''),
		COALESCE(pd.obat_racikan, ''),
		COALESCE(pd.is_kronis, '')
	FROM penjualandetails pd
	LEFT JOIN masterobats mo ON mo.id = pd.masterobat_id
	WHERE pd.penjualan_id IN (` + placeholders + `)
	AND pd.deleted_at IS NULL
	ORDER BY pd.penjualan_id DESC, pd.id ASC
	`

	rows, err := r.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	details := make(map[int64][]MobilePatientPrescriptionDetail)
	for rows.Next() {
		var (
			prescriptionID int64
			detail         MobilePatientPrescriptionDetail
		)
		if err = rows.Scan(
			&prescriptionID,
			&detail.ID,
			&detail.DrugName,
			&detail.DrugCode,
			&detail.Unit,
			&detail.Quantity,
			&detail.HowToUse,
			&detail.Dose,
			&detail.InfoPrimary,
			&detail.InfoExtra,
			&detail.Note,
			&detail.Label,
			&detail.Compound,
			&detail.Chronic,
		); err != nil {
			return nil, err
		}
		details[prescriptionID] = append(details[prescriptionID], detail)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return details, nil
}

func normalizeMobileLimit(limit int) int {
	if limit < 1 {
		return 20
	}
	if limit > 100 {
		return 100
	}
	return limit
}

func sqlPlaceholders(count int) string {
	if count <= 0 {
		return ""
	}

	return strings.TrimSuffix(strings.Repeat("?,", count), ",")
}

func normalizeGender(value string) string {
	normalized := strings.ToLower(strings.TrimSpace(value))
	switch normalized {
	case "l", "1", "m", "male", "laki", "laki-laki", "laki laki":
		return "Laki-laki"
	case "p", "2", "f", "female", "perempuan":
		return "Perempuan"
	default:
		return strings.TrimSpace(value)
	}
}

func normalizePatientType(value string) string {
	normalized := strings.ToLower(strings.TrimSpace(value))
	switch normalized {
	case "umum", "u", "2":
		return "Umum"
	case "jkn", "bpjs", "1":
		return "JKN/BPJS"
	default:
		return strings.TrimSpace(value)
	}
}

func normalizePaymentType(value string) string {
	normalized := strings.ToLower(strings.TrimSpace(value))
	switch normalized {
	case "1", "bpjs", "jkn":
		return "JKN/BPJS"
	case "2", "umum":
		return "Umum"
	default:
		return strings.TrimSpace(value)
	}
}
