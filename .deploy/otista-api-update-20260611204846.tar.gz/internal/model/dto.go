package model

type RegisterRequest struct {
	Username         string
	Email            string
	Password         string
	NoRM             string
	Phone            string
	FullName         string
	HasMedicalRecord bool
}

type LoginRequest struct {
	Username   string
	Identifier string
	Email      string
	NoRM       string
	Password   string
}

type VerifyOTPRequestLogin struct {
	Username   string
	Identifier string
	Email      string
	OTP        string
}

type UserRegister struct {
	ID       int64
	Username string
	Email    string
	Otp      string
}

type VerifyEmailUser struct {
	Username string
	OTP      string
}

type VerifyOTPNewUser struct {
	Email string
	OTP   string
}

type SetPasswordRequest struct {
	Email    string
	Password string
}

type ForgotPasswordRequest struct {
	Identifier string
	Email      string
	NoRM       string
}

type ResetPasswordRequest struct {
	Identifier string
	Email      string
	NoRM       string
	OTP        string
	Password   string
}

type RequestMedicalRecordClaim struct {
	Email     string
	Password  string
	NoRM      string
	NIK       string
	BirthDate string
}

type ConfirmMedicalRecordClaim struct {
	Email string
	OTP   string
}

type BookingQueueRequest struct {
	Email        string
	NoRM         string
	PasiensID    int64
	PoliID       int64
	Tanggal      string
	JenisPasien  string
	Bayar        string
	DoctorID     string
	QueueGroup   string
	IsJkn        bool
	NomorAntrian string
}

type BookingQueueResponse struct {
	RegistrationID   int64  `json:"registration_id"`
	QueueID          int64  `json:"queue_id"`
	RegistrationCode string `json:"registration_code"`
	QueueNumber      string `json:"queue_number"`
	QueueCode        string `json:"queue_code"`
	QueueGroup       string `json:"queue_group"`
	PoliID           int64  `json:"poli_id"`
	PoliName         string `json:"poli_name"`
	QueueDate        string `json:"queue_date"`
	ServiceMode      string `json:"service_mode"`
	Existing         bool   `json:"existing"`
}

type MobileBookingListResponse struct {
	Items        []MobileBookingRecord      `json:"items"`
	StatusCounts []MobileBookingStatusCount `json:"status_counts"`
}

type MobileBookingRecord struct {
	RegistrationID     int64  `json:"registration_id"`
	QueueID            int64  `json:"queue_id"`
	RegistrationCode   string `json:"registration_code"`
	QueueNumber        string `json:"queue_number"`
	QueueCode          string `json:"queue_code"`
	QueueGroup         string `json:"queue_group"`
	QueueDate          string `json:"queue_date"`
	CreatedAt          string `json:"created_at"`
	RegistrationStatus string `json:"registration_status"`
	StatusReg          string `json:"status_reg"`
	QueueStatus        string `json:"queue_status"`
	QueueStatusLabel   string `json:"queue_status_label"`
	CallStatus         string `json:"call_status"`
	AlreadyCalled      bool   `json:"already_called"`
	PatientID          int64  `json:"patient_id"`
	NoRM               string `json:"no_rm"`
	PatientName        string `json:"nama_pasien"`
	PoliID             int64  `json:"poli_id"`
	PoliName           string `json:"poli_name"`
	DoctorID           int64  `json:"dokter_id"`
	DoctorName         string `json:"nama_dokter"`
	InputFrom          string `json:"input_from"`
	PatientType        string `json:"jenis_pasien"`
	PaymentType        string `json:"bayar"`
	Note               string `json:"keterangan"`
}

type MobileBookingStatusCount struct {
	Status string `json:"status"`
	Count  int    `json:"count"`
}

type BookingDoctorOption struct {
	ID          int64  `json:"id"`
	Nama        string `json:"nama"`
	KodeAntrian string `json:"kode_antrian"`
	KodeBpjs    string `json:"kode_bpjs"`
	GeneralCode string `json:"general_code"`
}

type BookingPoliOption struct {
	ID             int64                 `json:"id"`
	Nama           string                `json:"nama"`
	Kelompok       string                `json:"kelompok"`
	Politype       string                `json:"politype"`
	BpjsCode       string                `json:"bpjs"`
	KodeRuangan    string                `json:"kode_ruangan"`
	Buka           string                `json:"buka"`
	Tutup          string                `json:"tutup"`
	Praktik        string                `json:"praktik"`
	Kuota          int64                 `json:"kuota"`
	KuotaOnline    int64                 `json:"kuota_online"`
	Terisi         int64                 `json:"terisi"`
	QueueGroup     string                `json:"queue_group"`
	QueueGroupHint string                `json:"queue_group_hint"`
	Doctors        []BookingDoctorOption `json:"dokter_list"`
}

type BookingOptionsResponse struct {
	Poli BookingPoliOption `json:"poli"`
}
