-- History perubahan skema produksi API RSUD Otista Mobile.
--
-- Catatan penting:
-- 1. Database utama SIMRS sudah ada. Jangan membuat ulang database.
-- 2. Jangan menjalankan script import schema penuh di production.
-- 3. Jalankan query di file ini secara selektif sesuai kebutuhan, bukan asal run semua.
-- 4. Pastikan index/kolom belum ada sebelum menjalankan ALTER agar tidak error duplicate.
-- 5. Nama tabel auth mobile yang benar adalah `user_mobile`, bukan `user`.

-- ============================================================
-- 2026-05-29: Skema auth mobile sesuai database saat ini
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_mobile` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `no_rm` VARCHAR(20) NULL,
    `patient_id` BIGINT UNSIGNED NULL,
    `phone` VARCHAR(30) NULL,
    `full_name` VARCHAR(150) NULL,
    `password` VARCHAR(255) NOT NULL,
    `email_verified` BOOLEAN DEFAULT FALSE,
    `verification_token` VARCHAR(255) NULL,
    `verified_at` TIMESTAMP NULL DEFAULT NULL,
    `medical_record_verified_at` TIMESTAMP NULL DEFAULT NULL,
    `is_deleted` BOOLEAN DEFAULT FALSE,
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_user_email` (`email`),
    KEY `idx_user_mobile_no_rm` (`no_rm`),
    UNIQUE KEY `uk_user_patient_id` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `otp_user_mobile` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `otp_code` VARCHAR(10) NOT NULL,
    `expired_at` TIMESTAMP NOT NULL,
    `is_used` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_otp_user_mobile_user`
        FOREIGN KEY (`user_id`) REFERENCES `user_mobile` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `otp_verif_email_mobile` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `no_rm` VARCHAR(20) NULL,
    `phone` VARCHAR(30) NULL,
    `full_name` VARCHAR(150) NULL,
    `otp_code` VARCHAR(10) NOT NULL,
    `expired_at` TIMESTAMP NOT NULL,
    `is_used` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `otp_password_reset_mobile` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `otp_code` VARCHAR(10) NOT NULL,
    `expired_at` TIMESTAMP NOT NULL,
    `is_used` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_otp_password_reset_mobile_user`
        FOREIGN KEY (`user_id`) REFERENCES `user_mobile` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `otp_medical_record_claim_mobile` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `patient_id` BIGINT UNSIGNED NOT NULL,
    `no_rm` VARCHAR(20) NOT NULL,
    `patient_name` VARCHAR(150) NULL,
    `otp_code` VARCHAR(10) NOT NULL,
    `expired_at` TIMESTAMP NOT NULL,
    `is_used` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_otp_medical_record_claim_mobile_user`
        FOREIGN KEY (`user_id`) REFERENCES `user_mobile` (`id`)
        ON DELETE CASCADE,
    KEY `idx_otp_medical_record_claim_user` (`user_id`),
    KEY `idx_otp_medical_record_claim_no_rm` (`no_rm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Kolom tambahan untuk database yang pernah dibuat dengan skema auth lama.
-- Jalankan hanya jika kolom belum tersedia.
ALTER TABLE `user_mobile`
    ADD COLUMN `no_rm` VARCHAR(20) NULL AFTER `email`;

ALTER TABLE `user_mobile`
    ADD COLUMN `patient_id` BIGINT UNSIGNED NULL AFTER `no_rm`;

ALTER TABLE `user_mobile`
    ADD COLUMN `phone` VARCHAR(30) NULL AFTER `patient_id`;

ALTER TABLE `user_mobile`
    ADD COLUMN `full_name` VARCHAR(150) NULL AFTER `phone`;

ALTER TABLE `user_mobile`
    ADD COLUMN `email_verified` BOOLEAN DEFAULT FALSE AFTER `password`;

ALTER TABLE `user_mobile`
    ADD COLUMN `verification_token` VARCHAR(255) NULL AFTER `email_verified`;

ALTER TABLE `user_mobile`
    ADD COLUMN `verified_at` TIMESTAMP NULL DEFAULT NULL AFTER `verification_token`;

ALTER TABLE `user_mobile`
    ADD COLUMN `medical_record_verified_at` TIMESTAMP NULL DEFAULT NULL AFTER `verified_at`;

ALTER TABLE `user_mobile`
    ADD COLUMN `is_deleted` BOOLEAN DEFAULT FALSE AFTER `medical_record_verified_at`;

ALTER TABLE `user_mobile`
    ADD COLUMN `deleted_at` TIMESTAMP NULL DEFAULT NULL AFTER `is_deleted`;

ALTER TABLE `user_mobile`
    ADD COLUMN `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER `deleted_at`;

ALTER TABLE `user_mobile`
    ADD COLUMN `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;

ALTER TABLE `otp_verif_email_mobile`
    ADD COLUMN `no_rm` VARCHAR(20) NULL AFTER `email`;

ALTER TABLE `otp_verif_email_mobile`
    ADD COLUMN `phone` VARCHAR(30) NULL AFTER `no_rm`;

ALTER TABLE `otp_verif_email_mobile`
    ADD COLUMN `full_name` VARCHAR(150) NULL AFTER `phone`;

-- Index auth mobile.
-- Jalankan hanya jika index belum tersedia.
ALTER TABLE `user_mobile`
    ADD KEY `idx_user_mobile_no_rm` (`no_rm`);

ALTER TABLE `user_mobile`
    ADD UNIQUE KEY `uk_user_patient_id` (`patient_id`);

ALTER TABLE `otp_user_mobile`
    ADD KEY `idx_otp_user_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`);

ALTER TABLE `otp_verif_email_mobile`
    ADD KEY `idx_otp_verif_email_mobile_email_used_expired` (`email`, `is_used`, `expired_at`);

ALTER TABLE `otp_password_reset_mobile`
    ADD KEY `idx_otp_password_reset_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`);

ALTER TABLE `otp_medical_record_claim_mobile`
    ADD KEY `idx_otp_medical_record_claim_mobile_user_used_expired` (`user_id`, `is_used`, `expired_at`);

-- Index lama `uk_user_no_rm` tidak dipakai lagi karena relasi pasien
-- memakai `user_mobile.patient_id -> pasiens.id`.
-- Jalankan hanya jika index tersebut masih ada.
ALTER TABLE `user_mobile`
    DROP INDEX `uk_user_no_rm`;

-- ============================================================
-- 2026-06-08: Booking umum dan antrian poli mobile
-- ============================================================
--
-- Skema existing yang dipakai:
-- - `user_mobile.patient_id` -> `pasiens.id`
-- - `registrasis.pasien_id` -> `pasiens.id`
-- - `registrasis.poli_id` -> `polis.id`
-- - `registrasis.dokter_id` -> `pegawais.id` dalam bentuk string ID
-- - `registrasis.antrian_poli_id` -> `antrian_poli.id`
-- - `antrian_poli.registrasi_id` -> `registrasis.id`
--
-- API tidak membuat tabel antrian baru untuk fitur ini.
-- Nomor antrian umum disimpan di:
-- - `registrasis.nomorantrian`
-- - `antrian_poli.nomor`
--
-- Endpoint terkait:
-- - POST /api/v1/mobile/booking/general
-- - GET  /api/v1/mobile/booking/general
-- - GET  /api/v1/mobile/booking/general/mine
-- - GET  /api/v1/mobile/booking/options/{poli_id}

-- Index pendukung list booking pendaftaran.
-- Jalankan hanya jika index belum tersedia.
ALTER TABLE `registrasis`
    ADD INDEX `idx_registrasis_mobile_booking` (
        `input_from`,
        `pasien_id`,
        `poli_id`,
        `tgl_order`,
        `deleted_at`
    );

ALTER TABLE `antrian_poli`
    ADD INDEX `idx_antrian_poli_mobile_booking` (
        `poli_id`,
        `tanggal`,
        `status`,
        `panggil`,
        `nomor`
    );

-- ============================================================
-- 2026-06-10: History antrian, resep, lab, dan radiologi mobile
-- ============================================================

-- Satu pasien hanya boleh memiliki satu booking umum mobile per tanggal.
-- Index ini juga membantu halaman history nomor antrian pasien.
-- Jalankan hanya jika index belum tersedia.
ALTER TABLE `registrasis`
    ADD INDEX `idx_registrasis_mobile_patient_daily` (
        `pasien_id`,
        `tgl_order`,
        `input_from`,
        `jkn`,
        `deleted_at`
    );

-- Index pendukung resep/obat pasien dari `penjualans` dan `penjualandetails`.
-- Jalankan hanya jika index belum tersedia.
ALTER TABLE `penjualans`
    ADD INDEX `idx_penjualans_mobile_patient` (
        `registrasi_id`,
        `deleted_at`,
        `created_at`
    );

ALTER TABLE `penjualandetails`
    ADD INDEX `idx_penjualandetails_mobile_prescription` (
        `penjualan_id`,
        `deleted_at`
    );

-- Index pendukung hasil lab pasien.
-- Jalankan hanya jika index belum tersedia.
ALTER TABLE `hasillabs`
    ADD INDEX `idx_hasillabs_mobile_registration` (
        `registrasi_id`,
        `deleted_at`,
        `tgl_hasilselesai`,
        `tgl_pemeriksaan`
    );

-- Index pendukung radiologi pasien.
-- Jalankan hanya jika index belum tersedia.
ALTER TABLE `order_radiologi`
    ADD INDEX `idx_order_radiologi_mobile_registration` (
        `registrasi_id`,
        `created_at`
    );

ALTER TABLE `hasilradiologis`
    ADD INDEX `idx_hasilradiologis_mobile_registration` (
        `registrasi_id`,
        `created_at`
    );

ALTER TABLE `radiologi_ekspertises`
    ADD INDEX `idx_radiologi_ekspertises_mobile_patient` (
        `registrasi_id`,
        `pasien_id`,
        `tanggal_eksp`
    );
