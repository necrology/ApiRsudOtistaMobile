package repository

import (
	"context"
	"database/sql"
	"strings"
)

type HospitalRepository struct {
	DB *sql.DB
}

type RoomAvailability struct {
	ID           string `json:"id"`
	GeneralCode  string `json:"general_code"`
	Name         string `json:"nama"`
	ClassNames   string `json:"kelas"`
	RoomNames    string `json:"ruangan"`
	RoomCount    int64  `json:"jumlah_kamar"`
	TotalBeds    int64  `json:"jumlah_bed"`
	FilledBeds   int64  `json:"terisi"`
	EmptyBeds    int64  `json:"kosong"`
	ActiveStays  int64  `json:"rawat_inap_aktif"`
	Renovation   int64  `json:"renovasi"`
	LastUpdated  string `json:"updated_at"`
	Availability string `json:"keterangan"`
}

func NewHospitalRepository(db *sql.DB) *HospitalRepository {
	return &HospitalRepository{DB: db}
}

func (r *HospitalRepository) RoomAvailabilities(ctx context.Context, search string, limit int) ([]RoomAvailability, error) {
	search = strings.TrimSpace(search)
	limit = normalizeMobileLimit(limit)
	if limit < 20 {
		limit = 20
	}

	query := `
	SELECT
		room_group.id,
		room_group.general_code,
		room_group.nama,
		room_group.kelas,
		room_group.ruangan,
		room_group.jumlah_kamar,
		room_group.jumlah_bed,
		room_group.terisi,
		GREATEST(room_group.jumlah_bed - room_group.terisi, 0) AS kosong,
		room_group.rawat_inap_aktif,
		0 AS renovasi,
		room_group.updated_at,
		CASE
			WHEN room_group.jumlah_bed <= 0 THEN 'Bed belum tersedia'
			WHEN GREATEST(room_group.jumlah_bed - room_group.terisi, 0) > 0 THEN 'Tersedia'
			ELSE 'Penuh'
		END AS keterangan
	FROM (
		SELECT
			MIN(COALESCE(NULLIF(TRIM(a.general_code), ''), CAST(a.id AS CHAR))) AS id,
			MIN(COALESCE(NULLIF(TRIM(a.general_code), ''), CAST(a.id AS CHAR))) AS general_code,
			COALESCE(
				NULLIF(GROUP_CONCAT(DISTINCT NULLIF(TRIM(a.kelompok), '') ORDER BY a.kelompok SEPARATOR ', '), ''),
				MIN(COALESCE(NULLIF(TRIM(a.general_code), ''), CAST(a.id AS CHAR)))
			) AS nama,
			COALESCE(NULLIF(GROUP_CONCAT(DISTINCT NULLIF(TRIM(a.kelompok), '') ORDER BY a.kelompok SEPARATOR ', '), ''), '') AS kelas,
			COALESCE(NULLIF(GROUP_CONCAT(DISTINCT NULLIF(TRIM(b.nama), '') ORDER BY b.nama SEPARATOR ', '), ''), '') AS ruangan,
			COUNT(DISTINCT b.id) AS jumlah_kamar,
			COUNT(DISTINCT c.id) AS jumlah_bed,
			COUNT(DISTINCT CASE WHEN active_reg.id IS NOT NULL THEN c.id END) AS terisi,
			COUNT(DISTINCT CASE WHEN active_reg.id IS NOT NULL THEN c.id END) AS rawat_inap_aktif,
			COALESCE(DATE_FORMAT(MAX(COALESCE(c.updated_at, b.updated_at, a.updated_at)), '%Y-%m-%d %H:%i'), '') AS updated_at
		FROM kelompok_kelas a
		LEFT JOIN kamars b
			ON b.kelompokkelas_id = a.id
			AND b.deleted_at IS NULL
			AND COALESCE(b.hidden, '') <> 'Y'
		LEFT JOIN beds c
			ON c.kamar_id = b.id
			AND c.deleted_at IS NULL
			AND COALESCE(c.hidden, '') <> 'Y'
		LEFT JOIN rawatinaps ri
			ON ri.bed_id = c.id
			AND (ri.deleted_at IS NULL OR ri.deleted_at = '')
			AND ri.tgl_keluar IS NULL
		LEFT JOIN registrasis active_reg
			ON active_reg.id = ri.registrasi_id
			AND (active_reg.pulang IS NULL OR active_reg.pulang = '')
		WHERE a.deleted_at IS NULL
		GROUP BY COALESCE(NULLIF(TRIM(a.general_code), ''), CAST(a.id AS CHAR))
	) room_group
	WHERE
		? = ''
		OR room_group.general_code LIKE ?
		OR room_group.nama LIKE ?
		OR room_group.ruangan LIKE ?
	ORDER BY room_group.general_code ASC, room_group.nama ASC
	LIMIT ?
	`

	like := "%" + search + "%"
	rows, err := r.DB.QueryContext(ctx, query, search, like, like, like, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	items := make([]RoomAvailability, 0)
	for rows.Next() {
		var item RoomAvailability
		if err = rows.Scan(
			&item.ID,
			&item.GeneralCode,
			&item.Name,
			&item.ClassNames,
			&item.RoomNames,
			&item.RoomCount,
			&item.TotalBeds,
			&item.FilledBeds,
			&item.EmptyBeds,
			&item.ActiveStays,
			&item.Renovation,
			&item.LastUpdated,
			&item.Availability,
		); err != nil {
			return nil, err
		}
		items = append(items, item)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return items, nil
}
