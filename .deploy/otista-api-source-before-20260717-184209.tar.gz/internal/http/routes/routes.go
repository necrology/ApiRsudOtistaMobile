package routes

import (
	"database/sql"

	"apirusdotistamobile/internal/auth"
	"apirusdotistamobile/internal/config"
	"apirusdotistamobile/internal/http/handlers"
	"apirusdotistamobile/internal/repository"

	"github.com/gofiber/fiber/v2"
)

func Register(
	app *fiber.App,
	db *sql.DB,
	cfg config.Config,
) {

	repo := repository.NewResourceRepository(
		db,
		cfg.Database.Name,
	)

	// auth
	authRepo := repository.NewAuthRepository(db)

	authService := auth.NewService(
		authRepo,
		cfg.SMTP,
	)

	authHandler := handlers.NewAuthHandler(authService)

	app.Get("/", func(c *fiber.Ctx) error {
		return c.Redirect("/api/v1/health")
	})

	v1 := app.Group("/api/v1")

	healthHandler := handlers.NewHealthHandler(db)
	v1.Get("/health", healthHandler.Check)

	tableHandler := handlers.NewTableHandler(repo)
	mobilePatientRepo := repository.NewMobilePatientRepository(db)
	mobilePatientHandler := handlers.NewMobilePatientHandler(mobilePatientRepo)
	hospitalRepo := repository.NewHospitalRepository(db)
	hospitalHandler := handlers.NewHospitalHandler(hospitalRepo)
	holidayRepo := repository.NewHolidayRepository(db, cfg.Holiday)
	bookingRepo := repository.NewBookingRepository(db, holidayRepo)
	bookingHandler := handlers.NewBookingHandler(bookingRepo, authRepo, holidayRepo)

	v1.Get("/tables", tableHandler.Tables)
	v1.Get("/tables/:table/search", tableHandler.Search)
	v1.Get("/tables/:table", tableHandler.TableInfo)

	MobilePatientRoutes(v1, mobilePatientHandler)
	HospitalRoutes(v1, hospitalHandler)
	BookingRoutes(v1, bookingHandler)
	v1.Get("/:table/search", tableHandler.Search)
	v1.Get("/:table", tableHandler.Search)
	v1.Get("/:table/:id", tableHandler.Detail)

	AuthRoutes(v1, authHandler)
}
