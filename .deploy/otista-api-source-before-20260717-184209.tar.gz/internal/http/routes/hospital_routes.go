package routes

import (
	"apirusdotistamobile/internal/http/handlers"

	"github.com/gofiber/fiber/v2"
)

func HospitalRoutes(v1 fiber.Router, hospitalHandler *handlers.HospitalHandler) {
	hospital := v1.Group("/mobile/hospital")

	hospital.Get("/room-availabilities", hospitalHandler.RoomAvailabilities)
}
